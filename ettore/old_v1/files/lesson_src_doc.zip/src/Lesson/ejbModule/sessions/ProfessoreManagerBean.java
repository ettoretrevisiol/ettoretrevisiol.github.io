package sessions;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import entities.*;
import exceptions.*;
import sessions.interfaces.GuestManagerLocal;
import sessions.interfaces.ProfessoreManagerLocal;
import sessions.interfaces.ProfessoreManagerRemote;

@Stateless(name = "ProfessoreManagerBean")
public class ProfessoreManagerBean implements ProfessoreManagerLocal,
		ProfessoreManagerRemote {

	@PersistenceContext(unitName = "Lesson")
	private EntityManager mng;

	@EJB
	private GuestManagerLocal gml;

	@SuppressWarnings("unchecked")
	@Override
	public List<AssistenteBean> getAssistenti() {
		Query q = mng.createQuery("FROM AssistenteBean");
		return q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ProfessoreBean> getProfessore() {
		// TODO Auto-generated method stub
		Query q = mng.createQuery("FROM ProfessoreBean");
		return q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CorsoBean> ricercaCorso(String nome) {
		Query q = mng.createQuery("FROM CorsoBean WHERE Nome LIKE '%?1%'");
		q.setParameter(1, nome);
		return q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CorsoBean> ricercaCorsoProfessore() {
		Query q = mng
				.createQuery("SELECT c FROM ProfessoreBean AS p, IN (p.corsi) c WHERE p.ID_Utente = ?1");
		q.setParameter(1, gml.getUserID());
		return q.getResultList();

	}

	@Override
	public void creaCorso(String nome, String anno, String semestre,
			String descrizione, int id_ass) throws NotValidStringException,
			NotValidProfessoreException, NotValidCorsoException,
			NotValidLivelloException, NotValidUtenteException {

		if (nome == null || anno == null || semestre == null
				|| descrizione == null)
			throw new NotValidStringException("Stringa non valida!");
		if (nome.length() == 0 || anno.length() == 0 || semestre.length() == 0)
			throw new NotValidStringException("Stringa non valida!");

		AssistenteBean assistente;

		CorsoBean c = new CorsoBean();

		if (id_ass != 0) {

			Query q = mng
					.createQuery("FROM AssistenteBean WHERE ID_Assistente = ?1");
			q.setParameter(1, id_ass);

			try {
				assistente = (AssistenteBean) q.getSingleResult();
				c.setAssistente(assistente);
			} catch (Exception e) {
				throw new NotValidProfessoreException("L'assistente non esiste");
			}
		}

		Query q = mng
				.createQuery("FROM CorsoBean WHERE Nome = ?1 AND Anno = ?2");
		q.setParameter(1, nome);
		q.setParameter(2, anno);
		if (q.getResultList().size() > 0)
			throw new NotValidCorsoException("Il corso esiste gi�!");

		c.setNome(nome);
		c.setAnno(anno);
		c.setDescrizione(descrizione);
		q = mng.createQuery("FROM ProfessoreBean WHERE ID_Professore = ?1");
		q.setParameter(1, gml.getUserID());
		c.setProfessore((ProfessoreBean) q.getSingleResult());

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StudenteBean> ricercaStudente(String nome) {
		Query q = mng
				.createQuery("SELECT s FROM StudenteBean AS s JOIN UtenteBean AS u ON s.ID_Utente = u.ID_Utente "
						+ "WHERE (u.Nome LIKE '%?1%' OR u.Cognome LIKE '%?1%'");
		q.setParameter(1, nome);
		return q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MaterialeBean> ricercaMateriale() {
		Query q = mng
				.createQuery("FROM MaterialeBean WHERE ID_Professore = ?1");
		q.setParameter(1, gml.getUserID());
		return q.getResultList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<ContenutoBean> ricercaContenuti(String descrizione) {

		Query q = mng
				.createQuery("FROM ContenutoBean WHERE Descrizione LIKE '%?1%'");
		q.setParameter(1, descrizione);
		return q.getResultList();

	}

	@Override
	@SuppressWarnings("unchecked")
	public List<CorrettoreBean> getCorrettori(String nome) {

		Query q = mng
				.createQuery("SELECT c FROM CorrettoreBean AS c JOIN UtenteBean AS u ON c.ID_Utente = u.ID_Utente "
						+ "WHERE u.Nome LIKE '%?1%' OR u.Cognome LIKE '%?1%'");
		q.setParameter(1, nome);
		return q.getResultList();

	}

	@Override
	public void creaMateriale(String nome, String descrizione, String url,
			int id_con) throws NotValidStringException,
			NotValidContenutoException, NotValidProfessoreException,
			NotValidLivelloException, NotValidUtenteException {

		Query q = mng
				.createQuery("FROM ProfessoreBean WHERE ID_Professore = ?1");
		q.setParameter(1, gml.getUserID());
		ProfessoreBean p = ((ProfessoreBean) q.getSingleResult());

		if (nome == null || descrizione == null || url == null)
			throw new NotValidStringException("Stringa non valida!");
		if (nome.length() == 0 || url.length() == 0)
			throw new NotValidStringException("Stringa non valida!");

		q = mng.createQuery("FROM ContenutoBean WHERE ID_Contenuto = ?1");
		q.setParameter(1, id_con);
		ContenutoBean contenuto;

		try {
			contenuto = (ContenutoBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidUtenteException("L'utente non esiste");
		}

		if (contenuto.getCorso().getProfessore().getID() != p.getID())
			throw new NotValidContenutoException("Contenuto non valido!");

		MaterialeBean m = new MaterialeBean();
		m.setNome(nome);
		m.setDescrizione(descrizione);
		m.setURL(url);
		m.setContenuto(contenuto);
		m.setProfessore(p);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TestBean> ricercaTest(String descrizione) {
		// TODO Auto-generated method stub
		Query q = mng
				.createQuery("FROM TestBean WHERE Descrizione LIKE '%?1%'");
		q.setParameter(1, descrizione);
		return q.getResultList();
	}

	@Override
	public void assegnaAssistente(int id_corso, int id_ass)
			throws NotValidCorsoException, NotValidProfessoreException,
			NotValidLivelloException, NotValidUtenteException {

		Query q = mng.createQuery("FROM CorsoBean WHERE ID_Corso = ?1");
		q.setParameter(1, id_corso);
		CorsoBean corso;

		try {
			corso = (CorsoBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidCorsoException("Il corso non esiste!");
		}

		q = mng.createQuery("FROM AssistenteBean WHERE ID_Assistente = ?1");
		q.setParameter(1, id_corso);
		AssistenteBean assistente;

		try {
			assistente = (AssistenteBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidCorsoException("L'assistente non esiste!");
		}

		q = mng.createQuery("FROM ProfessoreBean WHERE ID_Professore = ?1");
		q.setParameter(1, gml.getUserID());
		ProfessoreBean p = ((ProfessoreBean) q.getSingleResult());

		Iterator<CorsoBean> it = p.getIteratoreCorsi();
		boolean trovato = false;

		while (it.hasNext()) {
			CorsoBean c = it.next();
			if (c.getID() == corso.getID()) {
				trovato = true;
				break;
			}
		}

		if (trovato == false)
			throw new NotValidCorsoException(
					"Corso non appartente al professore!");

		corso.setAssistente(assistente);

	}

	@Override
	public void assegnaCorrettoreUtente(int id_test, int id_ut)
			throws NotValidTestException, NotValidCorrettoreException,
			NotValidLivelloException, NotValidUtenteException {

		Query q = mng
				.createQuery("FROM ProfessoreBean WHERE ID_Professore = ?1");
		q.setParameter(1, gml.getUserID());
		ProfessoreBean p = ((ProfessoreBean) q.getSingleResult());

		q = mng.createQuery("FROM TestBean WHERE ID_Test = ?1");
		q.setParameter(1, id_test);
		TestBean test;

		try {
			test = (TestBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidTestException("Il test non esiste");
		}

		q = mng.createQuery("SELECT t FROM TestBean as t, CorsoBean as c "
				+ "WHERE t.ID_Corso = c.ID_Corso AND c.ID_Professore = ?1");
		q.setParameter(1, p.getID());
		if (!q.getResultList().contains(test))
			throw new NotValidTestException("Test non valido!");

		q = mng.createQuery("FROM UtenteBean WHERE ID = ?1");
		q.setParameter(1, id_ut);
		UtenteBean utente;

		try {
			utente = (UtenteBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidUtenteException("L'utente non esiste");
		}

		if (!utente.getLivelloUtente().equals("professore")
				&& !utente.getLivelloUtente().equals("assistente"))
			throw new NotValidCorrettoreException("Correttore non valido!");

		CorrettoreBean correttore = new CorrettoreBean();
		correttore.setUtente(utente);
		test.setCorrettore(correttore);
		mng.persist(correttore);

	}

	@Override
	public String assegnaCorrettoreSoftware(int id_test, int id_sw)
			throws NotValidTestException, NotValidSoftwareException,
			NotValidCorrettoreException, NotValidLivelloException {

		Query q = mng
				.createQuery("FROM ProfessoreBean WHERE ID_Professore = ?1");
		q.setParameter(1, gml.getUserID());
		ProfessoreBean p = ((ProfessoreBean) q.getSingleResult());

		q = mng.createQuery("FROM TestBean WHERE ID_Test = ?1");
		q.setParameter(1, id_test);
		TestBean test;

		try {
			test = (TestBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidTestException("Il test non esiste");
		}

		q = mng.createQuery("FROM TestBean as t, CorsoBean as c "
				+ "WHERE t.ID_Corso = c.ID_Corso AND c.ID_Professore = ?1");
		q.setParameter(1, p.getID());
		if (!q.getResultList().contains(test))
			throw new NotValidTestException("Test non valido!");

		q = mng.createQuery("FROM SoftwareBean WHERE ID_Software = ?1");
		q.setParameter(1, id_test);
		SoftwareBean software;

		try {
			software = (SoftwareBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidSoftwareException("Il software non esiste");
		}

		CorrettoreBean correttore = new CorrettoreBean();
		correttore.setSoftware(software);
		test.setCorrettore(correttore);
		mng.persist(correttore);

		double valutazione = 100;

		while (valutazione < 0 || valutazione > 5)
			valutazione = Math.random();

		if (valutazione == 0)
			return "Molto male";
		else if (valutazione == 1)
			return "Male";
		else if (valutazione == 2)
			return "Medio";
		else if (valutazione == 3)
			return "Bene";
		else if (valutazione == 4)
			return "Molto bene";
		else
			return "Con lode";

	}

	@SuppressWarnings("unchecked")
	public List<SoftwareBean> getSoftware() {
		Query q = mng.createQuery("FROM SoftwareBean");
		return q.getResultList();
	}

	@Override
	public void creaTest(boolean tipo, String data, String descrizione, int id,
			int id_dip) throws Exception {

		if (data == null || descrizione == null)
			throw new NotValidStringException("Stringa non valida!");
		if (data.length() == 0 || descrizione.length() == 0)
			throw new NotValidStringException("Stringa non valida!");

		Query q = mng.createQuery("FROM CorsoBean WHERE ID_Corso = ?1");
		q.setParameter(1, id);
		CorsoBean c = (CorsoBean) q.getSingleResult();

		q = mng.createQuery("FROM ProfessoreBean WHERE ID_Professore = ?1");
		q.setParameter(1, c.getProfessore().getID());
		ProfessoreBean p = (ProfessoreBean) q.getSingleResult();

		boolean trovato = false;

		while (p.getIteratoreCorsi().hasNext()) {
			if (p.getIteratoreCorsi().next().getID() == c.getID()) {
				trovato = true;
				break;
			}
		}

		if (trovato == false)
			throw new NotValidCorsoException("Corso inserito non valido");

		TestBean t = new TestBean();
		t.setCorso(c);

		Calendar cal = new GregorianCalendar();
		String g, m, a;
		g = data.substring(0, 1);
		m = data.substring(3, 4);
		a = data.substring(6, 9);
		cal.set(Integer.valueOf(g), Integer.valueOf(m), Integer.valueOf(a));
		t.setDataTest(cal);

		t.setDescrizione(descrizione);
		t.setTipoTest(tipo);

		q = mng.createQuery("FROM TestBean WHERE ID_Test = ?1");
		q.setParameter(1, id_dip);
		TestBean tDip = (TestBean) q.getSingleResult();

		while (t.getIteratoreDipendenze().hasNext())
			if (t.getIteratoreDipendenze().next().equals(tDip))
				throw new NotValidDipendenzaException(
						"Test inserito non valido");

		t.aggiungiDipendenza(tDip);

	}

	@Override
	public void correggiTest(int id, int matricola, int voto, String descrizione)
			throws NotValidStringException, NotValidStudenteException,
			NotValidPunteggioException, NotValidTestException,
			NotValidLivelloException {

		Query q = mng.createQuery("FROM TestBean WHERE ID_Test = ?1");
		q.setParameter(1, id);
		TestBean test;

		try {
			test = (TestBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidTestException("Il test non esiste");
		}

		if (voto <= 0 || voto >= 33)
			throw new NotValidPunteggioException("Voto inserito non valido");
		if (descrizione == null || descrizione.length() == 0)
			throw new NotValidStringException("Descrizione non inserita");
		if (test.getCorrettore().getID() != gml.getUserID())
			throw new NotValidTestException("Test non valido!");

		Iterator<StudenteBean> it = test.getIteratoreIscritti();
		RisultatoBean r = new RisultatoBean();
		boolean trovato = false;

		while (it.hasNext()) {
			StudenteBean s = it.next();
			if (s.getID() == matricola) {
				trovato = true;
				r.setStudente(s);
				break;
			}
		}

		if (trovato == false)
			throw new NotValidStudenteException("Studente non trovato");

		r.setDescrizione(descrizione);

		if (voto >= 18)
			r.setPassato(true);
		else
			r.setPassato(false);

		r.setPunteggio(voto);
		mng.persist(r);
	}

}
