package sessions;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import entities.*;
import exceptions.NotValidCorsoException;
import exceptions.NotValidTestException;
import sessions.interfaces.GuestManagerLocal;
import sessions.interfaces.StudenteManagerLocal;
import sessions.interfaces.StudenteManagerRemote;

@Stateless(name = "StudenteManagerBean")
public class StudenteManagerBean implements StudenteManagerRemote,
		StudenteManagerLocal {

	@PersistenceContext(unitName = "Lesson")
	private EntityManager mng;

	@EJB
	private GuestManagerLocal gml;

	@Override
	public StudenteBean getStudente(int id) {
		// TODO Auto-generated method stub
		Query q = mng.createQuery("FROM UtenteBean WHERE ID = ?1");
		q.setParameter(1, id);
		return (StudenteBean) q.getSingleResult();

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TestBean> ricercaTest(String descrizione) {
		// TODO Auto-generated method stub
		Query q = mng
				.createQuery("FROM TestBean WHERE Descrizione LIKE '%?1%'");
		q.setParameter(1, descrizione);
		return q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TestBean> ricercaTestIscrizione() {

		List<TestBean> test = new ArrayList<TestBean>();

		Query q = mng
				.createQuery("SELECT t FROM StudenteBean AS s, IN (s.test) t "
						+ "WHERE s.ID_Utente = ?1 AND t.Data BETWEEN CURDATE() AND '31/12/2099'");
		q.setParameter(1, gml.getUserID());
		test = q.getResultList();

		while (test.iterator().hasNext()) {
			TestBean t = test.iterator().next();
			while (t.getIteratoreDipendenze().hasNext()) {
				while (test.iterator().next().getIteratoreDipendenze().next()
						.getIteratoreRisultati().hasNext()) {
					RisultatoBean r = test.iterator().next()
							.getIteratoreDipendenze().next()
							.getIteratoreRisultati().next();
					if (r.getPassato() != true)
						test.remove(t);
				}
			}
		}
		return test;
	}

	@Override
	public boolean iscrizioneTest(int id_test) throws NotValidTestException {

		Query q = mng.createQuery("FROM TestBean WHERE ID_Test = ?1");
		q.setParameter(1, id_test);
		TestBean test;

		try {
			test = (TestBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidTestException("Il test non esiste");
		}

		q = mng.createQuery("FROM IscrizioneTest WHERE Matricola_Studente = ?1 AND ID_Test = ?2");
		q.setParameter(1, gml.getUserID());
		q.setParameter(2, test.getID());
		if (q.getResultList().size() > 0)
			throw new NotValidTestException(
					"Lo Studente risulta gi� iscritto al test!");

		q = mng.createQuery("INSERT INTO IscrizioneTest VALUES(?1,?2)");
		q.setParameter(1, gml.getUserID());
		q.setParameter(2, test.getID());
		q.executeUpdate();
		return true;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CorsoBean> ricercaCorso(String nome) {
		// TODO Auto-generated method stub
		Query q = mng.createQuery("FROM CorsoBean WHERE Nome LIKE '%?1%'");
		q.setParameter(1, nome);
		return q.getResultList();
	}

	@Override
	public boolean iscrizioneCorso(int id_corso) throws NotValidCorsoException {
		// TODO Auto-generated method stub

		Query q = mng.createQuery("FROM CorsoBean WHERE ID_Corso = ?1");
		q.setParameter(1, id_corso);
		CorsoBean corso;

		try {
			corso = (CorsoBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidCorsoException("Il corso non esiste");
		}

		q = mng.createQuery("FROM IscrizioneCorso WHERE Matricola_Studente = ?1 AND ID_Corso = ?2");
		q.setParameter(1, gml.getUserID());
		q.setParameter(2, corso.getID());
		if (q.getResultList().size() > 0)
			throw new NotValidCorsoException(
					"Lo Studente risulta gi� iscritto al corso!");

		q = mng.createQuery("INSERT INTO IscrizioneTest VALUES(?1,?2)");
		q.setParameter(1, gml.getUserID());
		q.setParameter(2, corso.getID());
		q.executeUpdate();
		return true;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MaterialeBean> ricercaMateriale(String nome) {
		// TODO Auto-generated method stub
		Query q = mng.createQuery("FROM MaterialeBean WHERE Nome LIKE '%?1%'");
		q.setParameter(1, nome);
		return q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RisultatoBean> ricercaRisultato() {
		// TODO Auto-generated method stub
		Query q = mng
				.createQuery("FROM RisultatoBean WHERE MatricolaStudente = ?1");
		q.setParameter(1, gml.getUserID());
		return q.getResultList();
	}

}
