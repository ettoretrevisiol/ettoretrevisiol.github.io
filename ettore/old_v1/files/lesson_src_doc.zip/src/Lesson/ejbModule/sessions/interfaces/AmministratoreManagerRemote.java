package sessions.interfaces;

import java.util.List;
import javax.ejb.Remote;
import entities.UtenteBean;
import exceptions.NotValidLivelloException;
import exceptions.NotValidStringException;
import exceptions.NotValidUtenteException;

@Remote
public interface AmministratoreManagerRemote {

	/**
	 * Restituisce tutti gli utenti
	 * 
	 * @return List<UtenteBean>
	 */
	public List<UtenteBean> listaUtenti();

	/**
	 * Permette di ricercare un utente dal nome o dal cognome
	 * 
	 * @param cognome
	 *            Intero oppure parte del nome o del cognome
	 * @return List<UtenteBean>
	 */
	public List<UtenteBean> ricercaUtente(String cognome);

	/**
	 * Permette di salvare tutte le modifiche anagrafiche fatte all'utente
	 * 
	 * @param utente
	 */
	public void modificaUtente(UtenteBean utente);

	/**
	 * Permette di far salire o scendere il livello di autenticazione di un
	 * particolare utente
	 * 
	 * @param utente
	 *            L'utente cui modificare il livello di autenticazione
	 * @param livello
	 *            Il livello da settare
	 * @throws NotValidLivelloException
	 *             Il livello passato non esiste o non � valido
	 */
	public void modificaDiritti(int id, String livello)
			throws NotValidStringException, NotValidLivelloException;

	/**
	 * Permette di cancellare definitivamente un utente
	 * 
	 * @param utente
	 * @throws NotValidLivelloException
	 * @throws NotValidUtenteException
	 */
	public void cancellaUtente(int id) throws NotValidUtenteException;

}
