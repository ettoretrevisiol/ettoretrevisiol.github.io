package sessions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import entities.*;
import exceptions.*;
import sessions.interfaces.AssistenteManagerLocal;
import sessions.interfaces.AssistenteManagerRemote;
import sessions.interfaces.GuestManagerLocal;

@Stateless(name = "AssistenteManagerBean")
public class AssistenteManagerBean implements AssistenteManagerRemote,
		AssistenteManagerLocal {

	@PersistenceContext(unitName = "Lesson")
	private EntityManager mng;

	@EJB
	private GuestManagerLocal gml;

	@Override
	public AssistenteBean getAssistente(int id) {

		Query q = mng
				.createQuery("FROM AssistenteBean WHERE ID_Assistente = ?1");
		q.setParameter(1, id);
		return (AssistenteBean) q.getSingleResult();

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TestBean> ricercaTest(String descrizione) {

		Query q = mng
				.createQuery("FROM TestBean WHERE Descrizione LIKE '%?1%'");
		q.setParameter(1, descrizione);
		return q.getResultList();

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TestBean> ricercaTestCorrezione() {

		List<TestBean> test = new ArrayList<TestBean>();

		Query q = mng
				.createQuery("SELECT t FROM AssistenteBean AS a JOIN a.corsi AS c JOIN c.test "
						+ "WHERE a.ID_Utente = ?1");
		q.setParameter(1, gml.getUserID());
		test = q.getResultList();

		List<TestBean> testCorretti = new ArrayList<TestBean>();

		while (test.iterator().hasNext()) {
			TestBean t = test.iterator().next();
			if (t.getStatoTest() == true)
				testCorretti.add(t);
		}

		return testCorretti;

	}

	@Override
	public void correggiTest(int id, int matricola, int voto, String descrizione)
			throws NotValidStringException, NotValidStudenteException,
			NotValidPunteggioException, NotValidTestException,
			NotValidLivelloException {

		Query q = mng.createQuery("FROM TestBean WHERE ID_Test = ?1");
		q.setParameter(1, id);
		TestBean test;

		try {
			test = (TestBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidTestException("Il test non esiste");
		}

		if (voto <= 0 || voto >= 33)
			throw new NotValidPunteggioException("Voto inserito non valido");
		if (descrizione == null || descrizione.length() == 0)
			throw new NotValidStringException("Descrizione non inserita");
		if (test.getCorrettore().getID() != gml.getUserID())
			throw new NotValidTestException("Test non valido!");

		Iterator<StudenteBean> it = test.getIteratoreIscritti();
		RisultatoBean r = new RisultatoBean();
		boolean trovato = false;

		while (it.hasNext()) {
			StudenteBean s = it.next();
			if (s.getID() == matricola) {
				trovato = true;
				r.setStudente(s);
				break;
			}
		}

		if (trovato == false)
			throw new NotValidStudenteException("Studente non trovato");

		r.setDescrizione(descrizione);

		if (voto >= 18)
			r.setPassato(true);
		else
			r.setPassato(false);

		r.setPunteggio(voto);
		mng.persist(r);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<StudenteBean> ricercaStudente(String nome) {
		Query q = mng
				.createQuery("SELECT s FROM StudenteBean AS s JOIN UtenteBean AS u ON s.ID_Utente = u.ID_Utente "
						+ "WHERE (u.Nome LIKE '%?1%' OR u.Cognome LIKE '%?1%'");
		q.setParameter(1, nome);
		return q.getResultList();
	}

}
