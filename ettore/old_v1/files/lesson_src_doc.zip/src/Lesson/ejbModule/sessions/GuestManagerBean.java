package sessions;

import javax.ejb.*;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.jboss.ejb3.annotation.RemoteBinding;
import entities.AssistenteBean;
import entities.ProfessoreBean;
import entities.StudenteBean;
import entities.UtenteBean;
import exceptions.NotValidUtenteException;
import sessions.interfaces.*;

@RemoteBinding(jndiBinding = "GuestManagerRemote")
@Stateful(name = "GuestManagerBean")
public class GuestManagerBean implements GuestManagerLocal, GuestManagerRemote {

	@PersistenceContext(unitName = "Lesson")
	private EntityManager mng;

	private int userID = -1;
	// verr� usato durante tutta la sessione dell'utente
	private int utente;
	private String password;

	@Override
	public int salvaUtente(UtenteBean utente, String password) throws Exception {

		Query q = mng.createQuery("FROM UtenteBean WHERE CodiceFiscale = ?1");
		q.setParameter(1, utente.getCF());
		if (q.getResultList().size() > 0)
			throw new NotValidUtenteException("Utente gi� esistente!");
		else {
			utente.setLivelloUtente("utente");
			// pu� lanciare eccezione sulla string
			mng.persist(utente);
		}

		q = mng.createQuery("FROM UtenteBean WHERE CodiceFiscale = ?1");
		q.setParameter(1, utente.getCF());
		return ((UtenteBean) q.getSingleResult()).getID();

	}

	@Override
	public int login(int utente, String password) {
		// � l'id della persona

		this.utente = utente;
		this.password = password;

		if (loginAmministratore())
			return 0;

		if (loginAssistente())
			return 1;

		if (loginProfessore())
			return 2;

		if (loginStudente())
			return 3;

		return -1;

	}

	private boolean loginAmministratore() {

		// l'amministratore ha il login speciale
		if (utente == 0 && password.equals("root"))
			return true;
		return false;

	}

	private boolean loginAssistente() {

		AssistenteBean a = mng.find(AssistenteBean.class, utente);
		UtenteBean u = mng.find(UtenteBean.class, utente);

		if (a == null)
			return false;
		if (!u.getPassword().equals(password))
			return false;
		userID = u.getID();
		return true;

	}

	private boolean loginProfessore() {

		ProfessoreBean p = mng.find(ProfessoreBean.class, utente);
		UtenteBean u = mng.find(UtenteBean.class, utente);

		if (p == null)
			return false;
		if (!u.getPassword().equals(password))
			return false;
		userID = u.getID();
		return true;

	}

	private boolean loginStudente() {

		StudenteBean s = mng.find(StudenteBean.class, utente);
		UtenteBean u = mng.find(UtenteBean.class, utente);

		if (s == null)
			return false;
		if (!u.getPassword().equals(password))
			return false;
		userID = u.getID();
		return true;

	}

	@Override
	public void logout() throws Exception {
		if (userID == -1)
			throw new Exception("Non sei loggato!");
	}

	@Override
	public int getUserID() {
		// TODO Auto-generated method stub
		return userID;
	}

}
