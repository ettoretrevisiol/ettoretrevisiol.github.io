package sessions.interfaces;

import java.util.List;

import javax.ejb.Remote;
import entities.*;
import exceptions.NotValidLivelloException;
import exceptions.NotValidPunteggioException;
import exceptions.NotValidStringException;
import exceptions.NotValidStudenteException;
import exceptions.NotValidTestException;

@Remote
public interface AssistenteManagerRemote {

	/**
	 * Restituisce l'assistente attraverso l'identificativo
	 * 
	 * @param id
	 *            L'ID_Utente dell'assistente
	 * @return AssistenteBean
	 */
	public AssistenteBean getAssistente(int id);

	/**
	 * Permette di ricercare un test tramite una descrizione di massima
	 * 
	 * @param descrizione
	 *            Parte o Intera descrizione
	 * @return List<TestBean>
	 */
	public List<TestBean> ricercaTest(String descrizione);

	/**
	 * Restituisce tutti i test che l'assistente pu� correggere
	 * 
	 * @return List<TestBean>
	 */
	public List<TestBean> ricercaTestCorrezione();

	/**
	 * Permette all'assistente di inserire i dati riguardanti la correzione
	 * dello specifico test di uno studente
	 * 
	 * @param test
	 *            Il test corretto
	 * @param matricola
	 *            La matricola dello studente cui appartiene il compito
	 * @param voto
	 *            Il voto del compito da assegnare allo studente
	 * @param descrizione
	 *            Descrizione di massima del risultato
	 * @throws NotValidStringException
	 *             Una o pi� stringhe immesse non sono valide
	 * @throws NotValidStudenteException
	 *             Lo studente non esiste
	 * @throws NotValidPunteggioException
	 *             Il punteggio immesso non � valido
	 * @throws NotValidTestException
	 *             Il test non esiste oppure il correttore assegnato � diverso
	 * @throws NotValidLivelloException
	 */
	public void correggiTest(int id, int matricola, int voto,
			String descrizione) throws NotValidStringException,
			NotValidStudenteException, NotValidPunteggioException,
			NotValidTestException, NotValidLivelloException;

	/**
	 * Permette di cercare uno studente
	 * @param nome
	 * @return
	 */
	List<StudenteBean> ricercaStudente(String nome);

}
