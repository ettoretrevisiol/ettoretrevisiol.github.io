package sessions.interfaces;

import java.util.List;

import javax.ejb.Remote;
import entities.*;
import exceptions.NotValidContenutoException;
import exceptions.NotValidCorrettoreException;
import exceptions.NotValidCorsoException;
import exceptions.NotValidLivelloException;
import exceptions.NotValidProfessoreException;
import exceptions.NotValidPunteggioException;
import exceptions.NotValidSoftwareException;
import exceptions.NotValidStringException;
import exceptions.NotValidStudenteException;
import exceptions.NotValidTestException;
import exceptions.NotValidUtenteException;

@Remote
public interface ProfessoreManagerRemote {

	/**
	 * Restituisce tutti i professori
	 * 
	 * @return List<ProfessoreBean>
	 */
	public List<ProfessoreBean> getProfessore();

	/**
	 * Permette di ricercare un corso tramite il nome
	 * 
	 * @param nome
	 *            Intero o parte del nome
	 * @return List<CorsoBean>
	 */
	public List<CorsoBean> ricercaCorso(String nome);

	/**
	 * Permette di ricercare tutti i corsi del professore
	 * 
	 * @return List<CorsoBean>
	 */
	public List<CorsoBean> ricercaCorsoProfessore();

	/**
	 * Permette di ricercare uno studente dal nome o dal cognome
	 * 
	 * @param nome
	 *            Intero o parte del nome o del cognome
	 * @return List<StudenteBean>
	 */
	public List<StudenteBean> ricercaStudente(String nome);

	/**
	 * Permette di ricercare un test tramite la sua descrizione
	 * 
	 * @param nome
	 *            Intero o parte della descrizione
	 * @return List<TestBean>
	 */
	public List<TestBean> ricercaTest(String nome);

	/**
	 * Permette di assegnare un assistente al corso
	 * 
	 * @param corso
	 *            Il corso
	 * @param assistente
	 *            L'assistente
	 * @throws NotValidCorsoException
	 *             Il corso non esiste oppure non � del professore
	 * @throws NotValidProfessoreException
	 *             L'assistente non esiste
	 * @throws NotValidUtenteException
	 * @throws NotValidLivelloException
	 */
	public void assegnaAssistente(int id_corso, int id_ass)
			throws NotValidCorsoException, NotValidProfessoreException,
			NotValidLivelloException, NotValidUtenteException;

	/**
	 * Permette di creare un nuovo corso
	 * 
	 * @param nome
	 *            Il nome del corso
	 * @param anno
	 *            L'anno in cui il corso si tiene
	 * @param semestre
	 *            Il semestre dell'anno in cui si tiene il corso
	 * @param descrizione
	 *            Descrizione di massima del corso
	 * @param assistente
	 *            L'assistente del corso
	 * @throws NotValidStringException
	 *             Una o pi� stringa non sono valide
	 * @throws NotValidProfessoreException
	 *             L'assistente non esiste
	 * @throws NotValidCorsoException
	 *             Il corso esiste gi�
	 * @throws NotValidLivelloException
	 * @throws NotValidUtenteException
	 */
	public void creaCorso(String nome, String anno, String semestre,
			String descrizione, int id_ass) throws NotValidStringException,
			NotValidProfessoreException, NotValidCorsoException,
			NotValidLivelloException, NotValidUtenteException;

	/**
	 * Restituisce tutti gli assistenti
	 * 
	 * @return
	 */
	public List<AssistenteBean> getAssistenti();

	/**
	 * Permette di creare un nuovo materiale inerente ad un certo contenuto di
	 * uno dei corsi del professore
	 * 
	 * @param nome
	 *            Il nome del materiale
	 * @param descrizione
	 *            Descrizione di massima del materiale
	 * @param url
	 *            Pagina web da cui � possibile ottenere il materiale
	 * @param contenuto
	 *            Contenuto del corso cui si riferisce il materiale
	 * @throws NotValidStringException
	 *             Una o pi� stringhe non sono valide
	 * @throws NotValidContenutoException
	 *             Il contenuto non esiste oppure non � inerente a nessun corso
	 *             del professore
	 * @throws NotValidProfessoreException
	 * @throws NotValidLivelloException
	 * @throws NotValidUtenteException
	 */
	public void creaMateriale(String nome, String descrizione, String url,
			int id_con) throws NotValidStringException,
			NotValidContenutoException, NotValidProfessoreException,
			NotValidLivelloException, NotValidUtenteException;

	/**
	 * Permette di ricercare i contenuti tramite una descrizione
	 * 
	 * @param descrizione
	 *            Intera o parte di una descrizione
	 * @return List<ContenutoBean>
	 */
	public List<ContenutoBean> ricercaContenuti(String descrizione);

	/**
	 * Permette di ricercare tutti i materiali creati dal professore
	 * 
	 * @return List<MaterialeBean>
	 */
	public List<MaterialeBean> ricercaMateriale();

	/**
	 * Permette di ricercare un correttore tramite nome o cognome
	 * 
	 * @param nome
	 *            Intero o parte di nome o cognome
	 * @return List<CorrettoreBean>
	 */
	public List<CorrettoreBean> getCorrettori(String nome);

	/**
	 * Permette di assegnare il correttore ad un test
	 * 
	 * @param test
	 *            Il test
	 * @param utente
	 *            L'utente che dovr� correggere, pu� essere un assistente o un
	 *            professore stesso
	 * @throws NotValidTestException
	 *             Il test non esiste o non � del professore
	 * @throws NotValidCorrettoreException
	 *             Il correttore non esiste o non pu� correggere questo test
	 * @throws NotValidLivelloException
	 * @throws NotValidUtenteException 
	 */
	public void assegnaCorrettoreUtente(int id_test, int id_ut)
			throws NotValidTestException, NotValidCorrettoreException,
			NotValidLivelloException, NotValidUtenteException;

	/**
	 * assegna la correzione di un test a un programma automatico
	 * che lo corregge istantanemente
	 * @param test
	 * @param software
	 * @throws NotValidTestException
	 * @throws NotValidCorrettoreException
	 * @throws NotValidSoftwareException
	 * @throws NotValidLivelloException
	 */
	public String assegnaCorrettoreSoftware(int id_test, int id_sw)
			throws NotValidTestException, NotValidCorrettoreException,
			NotValidSoftwareException, NotValidLivelloException;

	/**
	 * Restituisce tutti i software di correzione
	 * 
	 * @return List<SoftwareBean>
	 */
	public List<SoftwareBean> getSoftware();

	/**
	 * crea un test
	 * @param tipo
	 * @param data
	 * @param descrizione
	 * @param id
	 * @throws NotValidStringException 
	 * @throws NotValidCorsoException 
	 * @throws Exception 
	 */
	void creaTest(boolean tipo, String data, String descrizione, int id, int id_dip) throws NotValidStringException, NotValidCorsoException, Exception;

	/**
	 * Permette di correggere un test
	 * @param id
	 * @param matricola
	 * @param voto
	 * @param descrizione
	 * @throws NotValidStringException
	 * @throws NotValidStudenteException
	 * @throws NotValidPunteggioException
	 * @throws NotValidTestException
	 * @throws NotValidLivelloException
	 */
	void correggiTest(int id, int matricola, int voto, String descrizione)
			throws NotValidStringException, NotValidStudenteException,
			NotValidPunteggioException, NotValidTestException,
			NotValidLivelloException;
	
}
