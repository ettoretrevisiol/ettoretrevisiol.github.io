package sessions.interfaces;

import java.util.List;
import javax.ejb.Remote;
import entities.*;
import exceptions.NotValidCorsoException;
import exceptions.NotValidTestException;

@Remote
public interface StudenteManagerRemote {

	/**
	 * Restituisce uno studente tramite la matricola
	 * 
	 * @param id
	 *            La matricola
	 * @return StudenteBean
	 */
	public StudenteBean getStudente(int id);

	/**
	 * Permette di ricercare un test tramite la descrizione
	 * 
	 * @param descrizione
	 *            Intera o parte della descrizione
	 * @return List<TestBean>
	 */
	public List<TestBean> ricercaTest(String descrizione);

	/**
	 * Permette di ricercare tutti i test cui l'utente pu� iscriversi
	 * 
	 * @return List<TestBean>
	 */
	public List<TestBean> ricercaTestIscrizione();

	/**
	 * Permette di iscriversi al test
	 * 
	 * @param test
	 *            Il test
	 * @return Esisto dell'iscrizione
	 * @throws NotValidTestException
	 *             Il test non esiste oppure lo studente � gi� iscritto oppure
	 *             non pu� isciversi
	 */
	public boolean iscrizioneTest(int id_test) throws NotValidTestException;

	/**
	 * Permette di ricercare un corso tramite il nome
	 * 
	 * @param nome
	 *            Intero o parte del nome
	 * @return List<CorsoBean>
	 */
	public List<CorsoBean> ricercaCorso(String nome);

	/**
	 * Permette di iscriversi al corso
	 * 
	 * @param corso
	 *            Il corso
	 * @return Esisto dell'iscrizione
	 * @throws NotValidCorsoException
	 *             Il corso non esiste oppure lo studente � gi� iscritto
	 */
	public boolean iscrizioneCorso(int id_corso) throws NotValidCorsoException;

	/**
	 * Permette di ricercare del materiale tramite il nome
	 * 
	 * @param nome
	 *            Intero o parte del nome
	 * @return List<MaterialeBean>
	 */
	public List<MaterialeBean> ricercaMateriale(String nome);

	/**
	 * Permette di ricercare tutti i risultati dei test dello studente
	 * 
	 * @return List<RisultatoBean>
	 */
	public List<RisultatoBean> ricercaRisultato();

}
