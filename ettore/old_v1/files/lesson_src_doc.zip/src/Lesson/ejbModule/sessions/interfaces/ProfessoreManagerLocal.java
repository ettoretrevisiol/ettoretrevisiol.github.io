package sessions.interfaces;

import javax.ejb.Local;

@Local
public interface ProfessoreManagerLocal extends ProfessoreManagerRemote {

}
