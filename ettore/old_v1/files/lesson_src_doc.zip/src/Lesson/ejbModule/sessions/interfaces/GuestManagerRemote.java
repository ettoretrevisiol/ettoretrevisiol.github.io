package sessions.interfaces;

import javax.ejb.Remote;
import entities.UtenteBean;

@Remote
public interface GuestManagerRemote {

	/**
	 * Permette di salvare un nuovo utente nel database, dandogli diritti di
	 * accesso minimi
	 * 
	 * @param utente
	 *            L'utente con tutti i dati anagrafici
	 * @param password
	 *            La password da usare per fare il login
	 * @return La matricola o codice assegnata all'utente
	 * @throws Exception
	 *             L'utente esiste gi� oppure la password non � valida
	 */
	public int salvaUtente(UtenteBean utente, String password) throws Exception;

	/**
	 * Restituisce l'ID dell'attuale utente loggato
	 * 
	 * @return int
	 */
	public int getUserID();

	/**
	 * Permette di effettuare il login da parte di un qualunque utente
	 * 
	 * @param utente
	 *            L'ID dell'utente
	 * @param password
	 *            La password per il login
	 * @return Un numero intero diverso a seconda del tipo utente per confermare
	 *         la riuscita del login, oppure -1 nel caso di errore
	 */
	public int login(int utente, String password);

	/**
	 * Permette di effetuare il logout
	 * 
	 * @throws Exception
	 *             L'utente non � attualmente loggato
	 */
	public void logout() throws Exception;

}
