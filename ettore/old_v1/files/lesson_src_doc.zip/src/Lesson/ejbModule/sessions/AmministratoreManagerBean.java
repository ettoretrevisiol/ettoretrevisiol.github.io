package sessions;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.*;
import entities.AssistenteBean;
import entities.CorrettoreBean;
import entities.ProfessoreBean;
import entities.StudenteBean;
import entities.UtenteBean;
import exceptions.NotValidLivelloException;
import exceptions.NotValidStringException;
import exceptions.NotValidUtenteException;
import sessions.interfaces.AmministratoreManagerLocal;
import sessions.interfaces.AmministratoreManagerRemote;

@Stateless(name = "AmministratoreManagerBean")
public class AmministratoreManagerBean implements AmministratoreManagerRemote,
		AmministratoreManagerLocal {

	@PersistenceContext(unitName = "Lesson")
	private EntityManager mng;

	@SuppressWarnings("unchecked")
	@Override
	public List<UtenteBean> listaUtenti() {
		Query q = mng.createQuery("FROM UtenteBean");
		return q.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UtenteBean> ricercaUtente(String cognome) {
		Query q = mng
				.createQuery("FROM UtenteBean WHERE Nome LIKE '%?1%' OR Cognome LIKE '%?1%'");
		q.setParameter(1, cognome);
		return q.getResultList();

	}

	@Override
	public void modificaUtente(UtenteBean utente) {
		// TODO Auto-generated method stub
		mng.merge(utente);
	}

	@Override
	public void modificaDiritti(int id, String livello)
			throws NotValidStringException, NotValidLivelloException {
		// TODO Auto-generated method stub

		Query q = mng.createQuery("FROM UtenteBean WHERE ID = ?1");
		q.setParameter(1, id);
		UtenteBean utente;

		try {
			utente = (UtenteBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidLivelloException("L'utente non esiste");
		}

		if (utente.getLivelloUtente().equals("studente")) {
			StudenteBean s = mng.find(StudenteBean.class, utente.getID());
			mng.remove(s);
		}

		if (utente.getLivelloUtente().equals("professore")) {
			ProfessoreBean s = mng.find(ProfessoreBean.class, utente.getID());
			mng.remove(s);
		}

		if (utente.getLivelloUtente().equals("assistente")) {
			AssistenteBean s = mng.find(AssistenteBean.class, utente.getID());
			mng.remove(s);
		}

		if (utente.getLivelloUtente().equals("correttore")) {
			CorrettoreBean s = mng.find(CorrettoreBean.class, utente.getID());
			mng.remove(s);
		}

		utente.setLivelloUtente(livello);

		if (livello.equals("studente")) {
			StudenteBean studente = new StudenteBean();
			studente.setUtente(utente);
			mng.persist(studente);
		}

		if (livello.equals("professore")) {
			ProfessoreBean professore = new ProfessoreBean();
			professore.setUtente(utente);
			mng.persist(professore);
		}

		if (livello.equals("assistente")) {
			AssistenteBean assistente = new AssistenteBean();
			assistente.setUtente(utente);
			mng.persist(assistente);
		}

		if (livello.equals("correttore")) {
			CorrettoreBean correttore = new CorrettoreBean();
			correttore.setUtente(utente);
			mng.persist(correttore);
		}

	}

	@Override
	public void cancellaUtente(int id) throws NotValidUtenteException {
		// TODO Auto-generated method stub

		Query q = mng.createQuery("FROM UtenteBean WHERE ID = ?1");
		q.setParameter(1, id);
		UtenteBean utente;

		try {
			utente = (UtenteBean) q.getSingleResult();
		} catch (Exception e) {
			throw new NotValidUtenteException("L'utente non esiste");
		}

		if (utente.getLivelloUtente().equals("studente")) {
			StudenteBean s = mng.find(StudenteBean.class, utente.getID());
			mng.remove(s);
		}

		if (utente.getLivelloUtente().equals("professore")) {
			ProfessoreBean s = mng.find(ProfessoreBean.class, utente.getID());
			mng.remove(s);
		}

		if (utente.getLivelloUtente().equals("assistente")) {
			AssistenteBean s = mng.find(AssistenteBean.class, utente.getID());
			mng.remove(s);
		}

		if (utente.getLivelloUtente().equals("correttore")) {
			CorrettoreBean s = mng.find(CorrettoreBean.class, utente.getID());
			mng.remove(s);
		}

		mng.merge(utente);
		mng.remove(utente);

	}

}
