package exceptions;

@SuppressWarnings("serial")
public class NotValidStudenteException extends Exception {

	public NotValidStudenteException(String s) {
		super(s);
	}
}
