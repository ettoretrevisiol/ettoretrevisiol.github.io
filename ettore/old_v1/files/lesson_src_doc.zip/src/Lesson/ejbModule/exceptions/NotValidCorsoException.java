package exceptions;

@SuppressWarnings("serial")
public class NotValidCorsoException extends Exception {

	public NotValidCorsoException(String s) {
		super(s);
	}

}
