package exceptions;

@SuppressWarnings("serial")
public class NotValidRisultatoException extends Exception {
	public NotValidRisultatoException(String s) {
		super(s);
	}
}
