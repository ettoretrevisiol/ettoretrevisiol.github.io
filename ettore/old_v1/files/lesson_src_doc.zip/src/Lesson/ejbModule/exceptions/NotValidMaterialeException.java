package exceptions;

@SuppressWarnings("serial")
public class NotValidMaterialeException extends Exception {

	public NotValidMaterialeException(String s) {
		super(s);
	}

}
