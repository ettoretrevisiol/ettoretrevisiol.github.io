package exceptions;

@SuppressWarnings("serial")
public class NotValidDataException extends Exception {

	public NotValidDataException(String s){
		super(s);
	}
}
