package exceptions;

@SuppressWarnings("serial")
public class NotValidDipendenzaException extends Exception {

	public NotValidDipendenzaException(String s) {
		super(s);
	}
}
