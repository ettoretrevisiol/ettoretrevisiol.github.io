package exceptions;

@SuppressWarnings("serial")
public class NotValidTestException extends Exception {
	public NotValidTestException(String s) {
		super(s);
	}
}
