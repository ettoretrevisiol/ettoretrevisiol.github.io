package exceptions;

@SuppressWarnings("serial")
public class NotValidPunteggioException extends Exception {
	public NotValidPunteggioException(String s) {
		super(s);
	}
}
