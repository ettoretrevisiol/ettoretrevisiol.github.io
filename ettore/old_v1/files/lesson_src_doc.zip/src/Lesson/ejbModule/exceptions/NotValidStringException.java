package exceptions;

@SuppressWarnings("serial")
public class NotValidStringException extends Exception {

	public NotValidStringException() {
		super("Lunghezza non valida, massimo 255 caratteri!");
	}

	public NotValidStringException(String s) {
		super(s);
	}

}
