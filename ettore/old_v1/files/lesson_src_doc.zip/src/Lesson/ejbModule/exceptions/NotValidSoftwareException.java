package exceptions;

@SuppressWarnings("serial")
public class NotValidSoftwareException extends Exception {
	public NotValidSoftwareException(String s) {
		super(s);
	}
}
