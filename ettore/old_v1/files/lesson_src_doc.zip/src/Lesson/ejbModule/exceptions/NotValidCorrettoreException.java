package exceptions;

@SuppressWarnings("serial")
public class NotValidCorrettoreException extends Exception {
	public NotValidCorrettoreException(String s) {
		super(s);
	}
}
