package exceptions;

@SuppressWarnings("serial")
public class NotValidUtenteException extends Exception {

	public NotValidUtenteException(String s){
		super(s);
	}
}
