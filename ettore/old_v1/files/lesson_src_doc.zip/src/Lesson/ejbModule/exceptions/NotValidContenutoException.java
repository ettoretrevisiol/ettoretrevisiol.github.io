package exceptions;

@SuppressWarnings("serial")
public class NotValidContenutoException extends Exception {

	public NotValidContenutoException(String s) {
		super(s);
	}

}
