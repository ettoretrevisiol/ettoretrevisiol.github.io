package exceptions;

@SuppressWarnings("serial")
public class NotValidLivelloException extends Exception {
	
	public NotValidLivelloException(String s){
		super(s);
	}

}
