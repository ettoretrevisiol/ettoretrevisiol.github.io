package exceptions;

@SuppressWarnings("serial")
public class NotValidProfessoreException extends Exception {

	public NotValidProfessoreException(String s) {
		super(s);
	}

}
