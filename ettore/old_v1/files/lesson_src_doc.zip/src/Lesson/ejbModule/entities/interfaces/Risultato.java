package entities.interfaces;

import entities.StudenteBean;
import entities.TestBean;
import exceptions.*;

public interface Risultato {

	/**
	 * restituisce l'id dello studente a cui � associato il risultato
	 * @return int
	 */
	public int getIDStudente();
	
	/**
	 * restituisce l'id del test corrispondente
	 */
	public int getIDTest();
	
	/**
	 * restituisce lo studente che ha conseguito il risultato
	 * @return
	 */
	public StudenteBean getStudente();

	/**
	 * @param studente
	 * @throws NotValidStudenteException
	 * @throws NotValidLivelloException 
	 */
	public void setStudente(StudenteBean studente) throws NotValidStudenteException, NotValidLivelloException;

	/**
	 * fornisce il test a cui appartiene il risultato
	 * @return
	 */
	public TestBean getTest();

	/**
	 * @param test
	 * @throws NotValidTestException
	 */
	public void setTest(TestBean test) throws NotValidTestException;

	/**
	 * Restituisce la descrizione del risultato
	 * @return String
	 */
	public String getDescrizione();

	/**
	 * Permette di impostare la descrizione del risultato
	 * 
	 * @param descrizione
	 *            La descrizione del contenuto
	 * @throws NotValidDescriptionException
	 *             La descrizione supera i 255 caratteri
	 */
	public void setDescrizione(String descrizione)
			throws NotValidStringException;

	/**
	 * fornisce il voto conseguito
	 * @return
	 */
	public float getPunteggio();

	/**
	 * imposta il voto
	 * @param punteggio
	 * @throws NotValidPunteggioException
	 */
	public void setPunteggio(int punteggio) throws NotValidPunteggioException;

	/**
	 * permette di sapere se il test � stato passato
	 * @return
	 */
	public boolean getPassato();

	/**
	 * @param passato
	 */
	public void setPassato(boolean passato);

}
