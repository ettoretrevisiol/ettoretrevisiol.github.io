package entities.interfaces;

import java.util.Iterator;
import entities.AssistenteBean;
import entities.ContenutoBean;
import entities.ProfessoreBean;
import entities.StudenteBean;
import entities.TestBean;
import exceptions.*;

public interface Corso {

	/**
	 * Restituisce l'id del corso
	 * 
	 * @return int
	 */
	public int getID();

	/**
	 * Restituisce il nome del corso
	 * 
	 * @return String
	 */
	public String getNome();

	/**
	 * Permette di impostare il nome del corso
	 * 
	 * @param nome
	 *            Nome del corso
	 * @throws NotValidStringException
	 *             Il nome supera i 255 caratteri
	 */
	public void setNome(String nome) throws NotValidStringException;

	/**
	 * Restituisce l'anno del Corso, � sottoforma di stringa in quanto permette
	 * diciture come "2010/2011"
	 * 
	 * @return String
	 */
	public String getAnno();

	/**
	 * Permette di impostare l'anno del corso
	 * 
	 * @param anno
	 *            L'anno del corso sottoforma di stringa
	 * @throws NotValidStringException
	 *             La stringa supera i 255 caratteri
	 */
	public void setAnno(String anno) throws NotValidStringException;

	/**
	 * Restituisce il semestre in cui il corso � tenuto
	 * 
	 * @return String
	 */
	public String getSemestre();

	/**
	 * Permette di settare il semestre in cui � tenuto il corso
	 * 
	 * @param semestre
	 *            Il semestre del corso
	 * @throws NotValidStringException
	 *             La stringa supera i 255 caratteri
	 */
	public void setSemestre(String semestre) throws NotValidStringException;

	/**
	 * Restituisce la descrizione del corso
	 * 
	 * @return String
	 */
	public String getDescrizione();

	/**
	 * Permette di impostare la descrizione del corso
	 * 
	 * @param descrizione
	 *            Una descrizione del corso
	 * @throws NotValidStringException
	 *             La descrizione supera i 255 caratteri
	 */
	public void setDescrizione(String descrizione)
			throws NotValidStringException;

	/**
	 * Restituisce il docente del corso
	 * 
	 * @return Professore
	 */
	public ProfessoreBean getProfessore();

	/**
	 * Permette di impostare il docente del corso
	 * 
	 * @param professore
	 *            Il docente del corso
	 * @throws NotValidProfessoreException
	 *             Il professore non esiste
	 * @throws NotValidLivelloException 
	 */
	public void setProfessore(ProfessoreBean professore)
			throws NotValidProfessoreException, NotValidLivelloException;

	/**
	 * Permette di aggiungere un contenuto al corso
	 * 
	 * @param contenuto
	 *            Il contenuto da aggiungere
	 * @throws NotValidContenutoException
	 *             Il contenuto non esiste oppure non � inerente al corso oppure
	 *             � gi� presente nella lista
	 */
	public void aggiungiContenuto(ContenutoBean contenuto)
			throws NotValidContenutoException;

	/**
	 * Permette di eliminare un contenuto tra quelli del corso
	 * 
	 * @param contenuto
	 *            Il contenuto da eliminare
	 * @throws NotValidContenutoException
	 *             Il contenuto non esiste oppure non � presente nella lista
	 */
	public void eliminaContenuto(ContenutoBean contenuto)
			throws NotValidContenutoException;

	/**
	 * Restituisce un iteratore per navigare tra i contenuti del corso
	 * 
	 * @return Iterator
	 */
	public Iterator<ContenutoBean> getIteratoreContenuti();

	/**
	 * Permette di aggiungere un test intermedio al corso
	 * 
	 * @param test
	 *            Il test intermedio da aggiungere
	 */
	/* public void aggiungiTestIntermedio(TestIntermedio test); */

	/**
	 * Permette di eliminare un test intermedio tra quelli del corso
	 * 
	 * @param test
	 *            Il test intermedio da eliminare
	 */
	/* public void eliminaTestIntermedio(TestIntermedio test); */

	/**
	 * Restituisce un iteratore per navigare tra i test intermedi del corso
	 * 
	 * @return Iterator
	 */
	/* public Iterator<TestIntermedio> getIteratoreTestIntermedi(); */

	/**
	 * Restituisce il test finale del corso
	 * 
	 * @return TestFinale
	 */
	/* public TestFinale getTestFinale(); */

	/**
	 * Permette di impostare il test finale del corso
	 * 
	 * @param test
	 *            Il test finale del corso
	 */
	/* public void setTestFinale(TestFinale test); */

	/**
	 * Restituisce l'assistente del corso
	 * 
	 * @return Assistente
	 */
	public Assistente getAssistente();

	/**
	 * Permette di impostare l'assistente del corso
	 * 
	 * @param assistente
	 * @throws NotValidLivelloException 
	 * @throws NotValidUtenteException 
	 */
	public void setAssistente(AssistenteBean assistente) throws NotValidLivelloException, NotValidUtenteException;

	/**
	 * fornisce l'iteratore degli iscritti al corso
	 * @return iteratore
	 */
	public Iterator<StudenteBean> getIteratoreIscritti();

	/**
	 * aggiunge uno studente alla lista degli iscritti al corso
	 * @param iscritto
	 * @throws NotValidLivelloException 
	 * @throws NotValidStudenteException 
	 */
	public void aggiungiIscritto(StudenteBean iscritto) throws NotValidLivelloException, NotValidStudenteException;
	
	/**
	 * rimuove uno studente dalla lista degli iscritti
	 * @param iscritto
	 * @throws NotValidLivelloException 
	 * @throws NotValidStudenteException 
	 */
	public void eliminaIscritto(StudenteBean iscritto) throws NotValidLivelloException, NotValidStudenteException;

	/**
	 * aggiunge un test alla lista dei test del corso
	 * @param test
	 * @throws NotValidTestException 
	 */
	public void aggiungiTest(TestBean test) throws NotValidTestException;
	
	/**
	 * elimina un test dalla lista dei test 
	 * @param test
	 * @throws NotValidTestException 
	 */
	public void eliminaTest(TestBean test) throws NotValidTestException;
	
	/**
	 * fornisce l'iteratore dei test
	 * @return
	 */
	public Iterator<TestBean> getIteratoreTest();
	
}
