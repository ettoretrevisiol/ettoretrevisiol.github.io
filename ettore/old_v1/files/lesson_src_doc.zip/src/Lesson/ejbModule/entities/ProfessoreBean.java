package entities;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.*;

import entities.interfaces.Professore;
import exceptions.NotValidCorsoException;
import exceptions.NotValidMaterialeException;

@SuppressWarnings("serial")
@Entity
@Table(name = "Professore")
public class ProfessoreBean implements Professore, Serializable {

	@Id
	@Column(name = "ID_Professore")
	private int ID;
	
	@OneToOne
	@JoinColumn(name = "ID_Utente", referencedColumnName = "ID")
	private UtenteBean utente;

	@Column(name = "Telefono_Interno")
	private int telefono;

	@OneToMany(mappedBy = "professore")
	private Set<CorsoBean> corsi;

	@OneToMany(mappedBy = "professore")
	private Set<MaterialeBean> materiali;

	@Override
	public int getID() {
		// TODO Auto-generated method stub
		return ID;
	}

	@Override
	public int getNumeroInterno() {
		// TODO Auto-generated method stub
		return telefono;
	}

	@Override
	public void setNumeroInterno(int telefono) {
		// TODO Auto-generated method stub
		this.telefono = telefono;
	}

	@Override
	public void aggiungiCorso(CorsoBean corso) throws NotValidCorsoException {
		// TODO Auto-generated method stub
		if (corso == null)
			throw new NotValidCorsoException("Corso non esistente!");
		else if (!corso.getProfessore().equals(this))
			throw new NotValidCorsoException("Corso non valido!");
		else if (corsi.contains(corso))
			throw new NotValidCorsoException("Corso gi� presente!");
		else
			corsi.add(corso);
	}

	@Override
	public void eliminaCorso(CorsoBean corso) throws NotValidCorsoException {
		// TODO Auto-generated method stub
		if (corso == null)
			throw new NotValidCorsoException("Corso non esistente!");
		else if (!corsi.contains(corso))
			throw new NotValidCorsoException("Corso non presente");
		else
			corsi.remove(corso);

	}

	@Override
	public Iterator<CorsoBean> getIteratoreCorsi() {
		// TODO Auto-generated method stub
		return corsi.iterator();
	}

	@Override
	public void aggiungiMateriale(MaterialeBean materiale)
			throws NotValidMaterialeException {
		// TODO Auto-generated method stub
		if (materiale == null)
			throw new NotValidMaterialeException("Materiale non esistente!");
		else if (!materiale.getProfessore().equals(this))
			throw new NotValidMaterialeException("Materiale non valido!");
		else if (materiali.contains(materiale))
			throw new NotValidMaterialeException("Materiale gi� presente!");
		else
			materiali.add(materiale);

	}

	@Override
	public void eliminaMateriale(MaterialeBean materiale)
			throws NotValidMaterialeException {
		// TODO Auto-generated method stub
		if (materiale == null)
			throw new NotValidMaterialeException("Materiale non esistente!");
		else if (!materiali.contains(materiale))
			throw new NotValidMaterialeException("Materiale non presente");
		else
			materiali.remove(materiale);

	}

	@Override
	public Iterator<MaterialeBean> getIteratoreMateriali() {
		// TODO Auto-generated method stub
		return materiali.iterator();
	}

	@Override
	public UtenteBean getUtente() {
		// TODO Auto-generated method stub
		return utente;
	}

	@Override
	public void setUtente(UtenteBean utente) {
		this.utente = utente;
		this.ID = utente.getID();

	}

}
