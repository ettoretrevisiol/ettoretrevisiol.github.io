package entities;

import java.io.Serializable;
import javax.persistence.*;
import entities.interfaces.*;
import exceptions.*;

@SuppressWarnings("serial")
@Entity
@Table(name = "Risultato")
@IdClass(RisultatoPK.class)
public class RisultatoBean implements Risultato, Serializable {

	@Id
	@Column(name = "ID_Studente")
	private int IDStudente;

	@Id
	@Column(name = "ID_Test")
	private int IDTest;

	@ManyToOne
	@JoinColumn(name = "Test", referencedColumnName = "ID_Test")
	private TestBean test;

	@ManyToOne
	@JoinColumn(name = "Studente", referencedColumnName = "ID_Studente")
	private StudenteBean studente;

	@Column(name = "Descrizione")
	private String descrizione;

	@Column(name = "Punteggio")
	private float punteggio;

	@Column(name = "Passato")
	private boolean passato;

	public int getIDStudente() {
		return IDStudente;
	}

	public int getIDTest() {
		return IDTest;
	}

	@Override
	public StudenteBean getStudente() {
		return studente;
	}

	@Override
	public TestBean getTest() {
		// TODO Auto-generated method stub
		return test;
	}

	@Override
	public String getDescrizione() {
		// TODO Auto-generated method stub
		return descrizione;
	}

	@Override
	public void setDescrizione(String descrizione)
			throws NotValidStringException {
		if (descrizione == null || descrizione.length() == 0)
			throw new NotValidStringException("Nessuna descrizione inserita");
		else if (descrizione.length() > 255)
			throw new NotValidStringException(
					"Stringa troppo lunga, massimo 255 caratteri");
		else
			this.descrizione = descrizione;
	}

	@Override
	public float getPunteggio() {
		// TODO Auto-generated method stub
		return punteggio;
	}

	@Override
	public boolean getPassato() {
		// TODO Auto-generated method stub
		return passato;
	}

	@Override
	public void setStudente(StudenteBean studente)
			throws NotValidStudenteException, NotValidLivelloException {

		if (studente == null)
			throw new NotValidStudenteException("Studente non esistente!");
		else if (studente.getUtente().getLivelloUtente() != "studente")
			throw new NotValidLivelloException("Utente non valido");
		else {
			this.studente = studente;
			this.IDStudente = studente.getID();
		}
	}

	@Override
	public void setTest(TestBean test) throws NotValidTestException {

		if (test == null)
			throw new NotValidTestException("Test non esistente!");
		else
			this.test = test;
		this.IDTest = test.getID();
		// TODO Auto-generated method stub
	}

	@Override
	public void setPunteggio(int punteggio) throws NotValidPunteggioException {

		if (punteggio < 18 || punteggio > 33)
			throw new NotValidPunteggioException("Punteggio non valido!");
		else
			this.punteggio = punteggio;
		// TODO Auto-generated method stub

	}

	@Override
	public void setPassato(boolean passato) {

		this.passato = passato; // che sia 0 o 1 va benon, o devo controllare il
								// punteggio?
		// TODO Auto-generated method stub

	}
}
