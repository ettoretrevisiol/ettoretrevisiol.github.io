package entities.interfaces;

import java.util.Iterator;
import entities.*;
import exceptions.*;

public interface Professore {

	/**
	 * Restituisce l'id del Professore
	 * 
	 * @return int
	 */
	public int getID();

	/**
	 * fornisce le informazioni personali del professore
	 * 
	 * @return
	 */
	public UtenteBean getUtente();

	/**
	 * setta i parametri del professore
	 * 
	 * @param utente
	 */
	public void setUtente(UtenteBean utente);

	/**
	 * Restituisce il numero di telefono interno del professore
	 * 
	 * @return int
	 */
	public int getNumeroInterno();

	/**
	 * Permette di impostare il numero di telefono interno del professore
	 * 
	 * @param telefono
	 */
	public void setNumeroInterno(int telefono);

	/**
	 * Permette di aggiungere un corso tra quelli insegnati dal professore
	 * 
	 * @param corso
	 * @throws NotValidCorsoException
	 *             Il corso non esiste oppure il corso non � insegnato dal
	 *             professore oppure il corso � gi� presente
	 */
	public void aggiungiCorso(CorsoBean corso) throws NotValidCorsoException;

	/**
	 * Permette di rimuovere un corso tra quelli insegnati dal professore
	 * 
	 * @param corso
	 * @throws NotValidCorsoException
	 *             Il corso non esiste oppure il corso non � presente nella
	 *             lista
	 */
	public void eliminaCorso(CorsoBean corso) throws NotValidCorsoException;

	/**
	 * Restituisce un iteratore per navigare tra i corsi insegnati dal
	 * professore
	 * 
	 * @return Iterator
	 */
	public Iterator<CorsoBean> getIteratoreCorsi();

	/**
	 * Permette di aggiungere un materiale tra quelli creati dal professore
	 * 
	 * @param materiale
	 * @throws NotValidMaterialeException
	 *             Il materiale non esiste oppure il materiale non � stato
	 *             creato dal professore oppure il materiale � gi� presente
	 *             nella lista
	 */
	public void aggiungiMateriale(MaterialeBean materiale)
			throws NotValidMaterialeException;

	/**
	 * Permette di rimuovere un corso tra quelli creati dal professore
	 * 
	 * @param materiale
	 * @throws NotValidMaterialeException
	 *             Il materiale non esiste oppure il materiale non � presente
	 *             nella lista
	 */
	public void eliminaMateriale(MaterialeBean materiale)
			throws NotValidMaterialeException;

	/**
	 * Restituisce un iteratore per navigare tra i materiali creati dal
	 * professore
	 * 
	 * @return Iterator
	 */
	public Iterator<MaterialeBean> getIteratoreMateriali();

}
