package entities.interfaces;

import java.util.Iterator;

import entities.CorsoBean;
import entities.UtenteBean;
import exceptions.NotValidCorsoException;

public interface Assistente {

	/**
	 * restituisce l'id dell'assistente
	 * 
	 * @return ID
	 */
	public int getID();

	/**
	 * ritorna i dati personali dell'assistente
	 * 
	 * @return persona
	 */
	public UtenteBean getUtente();

	/**
	 * imposta i dati dell'assistente
	 * 
	 * @param p
	 */
	public void setUtente(UtenteBean utente);

	/**
	 * aggiunge un corso che � stato assegnato all'assistente
	 * 
	 * @param c
	 * @throws NotValidCorsoException
	 */
	public void aggiungiCorso(CorsoBean c) throws NotValidCorsoException;

	/**
	 * elimina un corso da quelli assegnati all'assistente
	 * 
	 * @param c
	 * @throws NotValidCorsoException
	 */
	public void eliminaCorso(CorsoBean c) throws NotValidCorsoException;

	/**
	 * ritorna l'iteratore che permette di visionare ogni corso assegnato
	 * all'ssistente
	 * 
	 * @return IteratoreCorsi
	 */
	public Iterator<CorsoBean> getIteratoreCorsi();

}
