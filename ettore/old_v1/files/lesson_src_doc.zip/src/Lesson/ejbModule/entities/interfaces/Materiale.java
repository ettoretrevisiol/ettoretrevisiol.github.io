package entities.interfaces;

import java.util.Iterator;

import entities.*;
import exceptions.*;

public interface Materiale {

	/**
	 * Restituisce l'id del materiale
	 * 
	 * @return
	 */
	public int getID();

	/**
	 * Restituisce la descrizione del materiale
	 * 
	 * @return
	 */
	public String getDescrizione();

	/**
	 * Permette di impostare la descrizione del materiale
	 * 
	 * @param descrizione
	 *            La descrizione del materiale
	 * @throws NotValidStringException
	 *             La descrizione supera i 255 caratteri
	 */
	public void setDescrizione(String descrizione)
			throws NotValidStringException;

	/**
	 * Restituisce il nome del materiale
	 * 
	 * @return String
	 */
	public String getNome();

	/**
	 * Permette di impostare il nome del materiale
	 * 
	 * @param nome
	 *            Il nome del materiale
	 * @throws NotValidStringException
	 *             Il nome supera i 255 caratteri
	 */
	public void setNome(String nome) throws NotValidStringException;

	/**
	 * Restituisce l'URL del materiale
	 * 
	 * @return String
	 */
	public String getURL();

	/**
	 * Permette di impostare l'URL del materiale
	 * 
	 * @param url
	 * @throws NotValidStringException
	 *             L'URL supera i 255 caratteri
	 */
	public void setURL(String url) throws NotValidStringException;

	/**
	 * Restituisce il contenuto del corso cui � inerente il materiale
	 * 
	 * @return ContenutoBean
	 */
	public ContenutoBean getContenuto();

	/**
	 * Permette di impostare il contenuto del materiale
	 * 
	 * @param contenuto
	 *            Il contenuto del corso su cui verte il materiale
	 * @throws NotValidContenutoException
	 *             Il contenuto non esiste
	 */
	public void setContenuto(ContenutoBean contenuto)
			throws NotValidContenutoException;

	/**
	 * Restituisce il professore che ha creato il materiale
	 * 
	 * @return ProfessoreBean
	 */
	public ProfessoreBean getProfessore();

	/**
	 * Permette di impostare il professore che ha creato il materiale
	 * 
	 * @param professore
	 * @throws NotValidProfessoreException
	 *             Il professore non esiste
	 * @throws NotValidLivelloException 
	 */
	public void setProfessore(ProfessoreBean professore)
			throws NotValidProfessoreException, NotValidLivelloException;

	/**
	 * Permette di aggiungere una dipendenza al materiale
	 * 
	 * @param materiale
	 *            Il materiale da cui dipender� questo
	 * @throws NotValidDipendenzaException
	 *             Il materiale non esiste oppure la dipendenza � riflessiva
	 *             oppure � simmetrica oppure � gi� presente nella lista
	 */
	public void aggiungiDipendenza(MaterialeBean materiale)
			throws NotValidDipendenzaException;

	// N.B.: le dipendenze circolari come le facciamo?

	/**
	 * Permette di rimuovere un materiale tra le dipendenze attuali
	 * 
	 * @param materiale
	 *            Il materiale da rimuovere
	 * @throws NotValidMaterialeException
	 *             Il materiale non esiste o non � presente nella lista
	 */
	public void eliminaDipendenza(MaterialeBean materiale)
			throws NotValidMaterialeException;

	/**
	 * Restituisce un iteratore per navigare tra le dipendenze attuali
	 * 
	 * @return Iterator
	 */
	public Iterator<MaterialeBean> getIteratoreDipendenze();

}
