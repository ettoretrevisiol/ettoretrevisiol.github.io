package entities;

import java.io.Serializable;

@SuppressWarnings("serial")
public class RisultatoPK implements Serializable {

	private int IDTest, IDStudente;

	public RisultatoPK() {
	}

	public boolean equals(Object o) {
		if (!(o instanceof Integer))
			return false;

		if (this.IDStudente == (Integer) o || this.IDTest == (Integer) 0)
			return true;
		else
			return false;
	}

	public int hashCode() {
		return 0;
	}

}
