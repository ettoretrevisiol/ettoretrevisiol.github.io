package entities.interfaces;

import java.util.Iterator;

import entities.UtenteBean;
import entities.SoftwareBean;
import entities.TestBean;
import exceptions.*;

public interface Correttore {

	/**
	 * Restituisce l'id dell'utente o del software
	 * 
	 * @return int
	 */
	public int getID();

	/**
	 * Imposta il parametro ID
	 * 
	 * @param id
	 */

	/**
	 * fornisce l'utente nel caso in cui il correttore sia una persona
	 */
	public UtenteBean getUtente();

	/**
	 * imposta l'utente
	 * 
	 * @param utente
	 * @throws NotValidUtenteException
	 * @throws NotValidLivelloException
	 */
	public void setUtente(UtenteBean utente) throws NotValidUtenteException,
			NotValidLivelloException;

	/**
	 * fornisce il software nel caso in cui il correttore sia un programma
	 * automatico
	 * 
	 * @return
	 */
	public SoftwareBean getSoftware();

	/**
	 * imposta il software
	 * 
	 * @param software
	 * @throws NotValidSoftwareException
	 */
	public void setSoftware(SoftwareBean software)
			throws NotValidSoftwareException;

	/**
	 * aggiunge un test all'isieme dei test assegnati al correttore
	 * 
	 * @param prova
	 * @throws NotValidTestException
	 */
	public void aggiungiProva(TestBean prova) throws NotValidTestException;

	/**
	 * elimina una prova dalla lista dei test del correttore
	 * 
	 * @param prova
	 * @throws NotValidTestException
	 */
	public void eliminaProva(TestBean prova) throws NotValidTestException;

	/**
	 * ritorna l'iteratore dei test assegnati
	 * 
	 * @return
	 */
	public Iterator<TestBean> getIteratoreProve();

}
