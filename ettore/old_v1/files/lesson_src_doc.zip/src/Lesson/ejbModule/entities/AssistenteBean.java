package entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import javax.persistence.*;

import entities.interfaces.Assistente;
import exceptions.NotValidCorsoException;

@SuppressWarnings("serial")
@Entity
@Table(name = "ASSISTENTE")
public class AssistenteBean implements Assistente, Serializable {

	@Id
	@Column(name = "ID_Assistente")
	private int ID;

	@OneToOne
	@JoinColumn(name = "ID_Utente", referencedColumnName = "ID")
	private UtenteBean utente;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "assistente")
	private Set<CorsoBean> corsi = new HashSet<CorsoBean>();

	@Override
	public int getID() {
		return ID;
	}

	@Override
	public void aggiungiCorso(CorsoBean c) throws NotValidCorsoException {
		if (c == null)
			throw new NotValidCorsoException("Corso inesistente");
		else if (this.corsi.contains(c))
			throw new NotValidCorsoException("Il corso esiste gi�");
		else
			this.corsi.add(c);
	}

	@Override
	public void eliminaCorso(CorsoBean c) throws NotValidCorsoException {
		if (c == null)
			throw new NotValidCorsoException("Corso inesistente");
		else if (!this.corsi.contains(c))
			throw new NotValidCorsoException("Corso non presente");
		else
			this.corsi.remove(c);
	}

	@Override
	public Iterator<CorsoBean> getIteratoreCorsi() {
		return this.corsi.iterator();
	}

	@Override
	public UtenteBean getUtente() {
		return utente;
	}

	@Override
	public void setUtente(UtenteBean utente) {
		this.utente = utente;
		this.ID = utente.getID();

	}

	@Override
	public boolean equals(Object o) {

		if (!(o instanceof MaterialeBean))
			return false;

		return this.getID() == ((MaterialeBean) o).getID();
	}

}
