package entities;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.*;
import entities.interfaces.Materiale;
import exceptions.*;

@SuppressWarnings("serial")
@Entity
@Table(name = "Materiale")
public class MaterialeBean implements Materiale, Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID_Materiale")
	private int id;

	@Column(name = "Descrizione")
	private String descrizione;

	@Column(name = "Nome")
	private String nome;

	@Column(name = "URL")
	private String url;

	@ManyToOne
	@JoinColumn(name = "Professore", referencedColumnName = "ID_Professore")
	private ProfessoreBean professore;

	@ManyToOne
	@JoinColumn(name = "Contenuto", referencedColumnName = "ID_Contenuto")
	private ContenutoBean contenuto;

	@ManyToMany
	@JoinTable(name = "Dipendenze_Materiale", joinColumns = @JoinColumn(name = "ID_MaterialeDipendente"), inverseJoinColumns = @JoinColumn(name = "ID_Materiale"))
	private Set<MaterialeBean> dipendenze;

	@Override
	public int getID() {
		// TODO Auto-generated method stub
		return id;
	}

	@Override
	public String getDescrizione() {
		// TODO Auto-generated method stub
		return descrizione;
	}

	@Override
	public void setDescrizione(String descrizione) throws NotValidStringException {
		if (descrizione == null || descrizione.length() == 0)
			throw new NotValidStringException("Descrizione non inserita");
		else if (nome.length() > 255)
			throw new NotValidStringException("Stringa troppo lunga, massimo 255 caratteri");
		else
			this.descrizione = descrizione;

	}

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return nome;
	}

	@Override
	public void setNome(String nome) throws NotValidStringException {
		if (nome == null || nome.length() == 0)
			throw new NotValidStringException("Nome non inserito");
		else if (nome.length() > 255)
			throw new NotValidStringException("Stringa troppo lunga, massimo 255 caratteri");
		else
			this.nome = nome;

	}

	@Override
	public String getURL() {
		// TODO Auto-generated method stub
		return url;
	}

	@Override
	public void setURL(String url) throws NotValidStringException {
		if (url == null || url.length() == 0)
			throw new NotValidStringException("URL non inserito");
		else if (url.length() > 255)
			throw new NotValidStringException("Stringa troppo lunga, massimo 255 caratteri");
		else
			this.url = url;

	}

	@Override
	public ContenutoBean getContenuto() {
		// TODO Auto-generated method stub
		return contenuto;
	}

	@Override
	public void setContenuto(ContenutoBean contenuto)
			throws NotValidContenutoException {
		// TODO Auto-generated method stub
		if (contenuto == null)
			throw new NotValidContenutoException("Contenuto non esistente!");
		else
			this.contenuto = contenuto;

	}

	@Override
	public ProfessoreBean getProfessore() {
		// TODO Auto-generated method stub
		return professore;
	}

	@Override
	public void setProfessore(ProfessoreBean professore)
			throws NotValidProfessoreException, NotValidLivelloException  {
		// TODO Auto-generated method stub
		if (professore == null)
			throw new NotValidProfessoreException("Professore non esistente!");
		else
			this.professore = professore;

	}

	@Override
	public void aggiungiDipendenza(MaterialeBean materiale)
			throws NotValidDipendenzaException {
		// TODO Auto-generated method stub
		if (materiale == null)
			throw new NotValidDipendenzaException("Materiale non esistente");
		else if (materiale.equals(this))
			throw new NotValidDipendenzaException("Dipendenza riflessiva");
		else if (materiale.dipendenze.contains(this))
			throw new NotValidDipendenzaException("Dipendenza simmetrica");
		else if (dipendenze.contains(materiale))
			throw new NotValidDipendenzaException("Dipendenza gi� presente");
		else
			dipendenze.add(materiale);

	}

	@Override
	public void eliminaDipendenza(MaterialeBean materiale)
			throws NotValidMaterialeException {
		// TODO Auto-generated method stub
		if (materiale == null)
			throw new NotValidMaterialeException("Materiale non esistente!");
		else if (!dipendenze.contains(materiale))
			throw new NotValidMaterialeException("Materiale non presente");
		else
			dipendenze.remove(materiale);

	}

	@Override
	public Iterator<MaterialeBean> getIteratoreDipendenze() {
		// TODO Auto-generated method stub
		return dipendenze.iterator();
	}

	@Override
	public String toString() {
		return descrizione;
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof MaterialeBean))
			return false;

		return this.getID() == ((MaterialeBean) o).getID();
	}
}
