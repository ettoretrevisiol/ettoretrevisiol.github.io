package entities;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;
import javax.persistence.*;
import entities.interfaces.*;
import exceptions.*;

@SuppressWarnings("serial")
@Entity
@Table(name = "Contenuto")
public class ContenutoBean implements Contenuto, Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID_Contenuto")
	private int id;

	@Column(name = "Descrizione")
	private String descrizione;

	@ManyToOne
	@JoinColumn(name = "Corso", referencedColumnName = "ID_Corso")
	private CorsoBean corso;

	@OneToMany(mappedBy = "contenuto")
	private Set<MaterialeBean> materiali;

	@Override
	public int getID() {
		// TODO Auto-generated method stub
		return id;
	}

	@Override
	public String getDescrizione() {
		// TODO Auto-generated method stub
		return descrizione;
	}

	@Override
	public void setDescrizione(String descrizione)
			throws NotValidStringException {
		if (descrizione == null || descrizione.length() == 0)
			throw new NotValidStringException("Descrizione non inserita");
		else if (descrizione.length() > 255)
			throw new NotValidStringException("Stringa inserita troppo lunga,massimo 255 caratteri");
		else
			this.descrizione = descrizione;

	}

	@Override
	public CorsoBean getCorso() {
		// TODO Auto-generated method stub
		return corso;

	}

	@Override
	public void setCorso(CorsoBean corso) throws NotValidCorsoException {
		// TODO Auto-generated method stub

		if (corso == null)
			throw new NotValidCorsoException("Corso non esistente!");
		else
			this.corso = corso;

	}

	@Override
	public Iterator<MaterialeBean> getIteratoreMateriali() {
		// TODO Auto-generated method stub
		return materiali.iterator();
	}

	@Override
	public void aggiungiMateriale(MaterialeBean materiale)
			throws NotValidMaterialeException {
		// TODO Auto-generated method stub

		if (materiale == null)
			throw new NotValidMaterialeException("Materiale non esistente!");
		else if (!materiale.getContenuto().equals(this))
			throw new NotValidMaterialeException("Materiale non valido!");
		else if (materiali.contains(materiale))
			throw new NotValidMaterialeException("Materiale gi� presente!");
		else
			materiali.add(materiale);

	}

	@Override
	public void eliminaMateriale(MaterialeBean materiale)
			throws NotValidMaterialeException {
		// TODO Auto-generated method stub

		if (materiale == null)
			throw new NotValidMaterialeException("Materiale non esistente!");
		else if (!materiali.contains(materiale))
			throw new NotValidMaterialeException("Materiale non presente");
		else
			materiali.remove(materiale);

	}

	// tests

	@Override
	public String toString() {
		return descrizione;
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof ContenutoBean))
			return false;

		return this.getID() == ((ContenutoBean) o).getID();
	}

}
