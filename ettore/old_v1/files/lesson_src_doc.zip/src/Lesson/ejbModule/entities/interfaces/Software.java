package entities.interfaces;

import exceptions.NotValidStringException;

public interface Software {

	/**
	 * Restituisce l'id del software
	 * 
	 * @return
	 */
	public int getID();

	/**
	 * Restituisce la descrizione del software
	 * 
	 * @return
	 */
	public String getDescrizione();

	/**
	 * Permette di impostare la descrizione del software
	 * 
	 * @param descrizione
	 *            La descrizione del materiale
	 * @throws NotValidStringException
	 *             La descrizione supera i 255 caratteri
	 */
	public void setDescrizione(String descrizione)
			throws NotValidStringException;

	/**
	 * @param nome
	 * @throws NotValidStringException 
	 */
	public void setNome(String nome) throws NotValidStringException;

	/**
	 * fornisce il nome del software utilizzato
	 * @return
	 */
	public String getNome();

}
