package entities;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Set;
import javax.persistence.*;

import entities.interfaces.*;
import exceptions.*;

@SuppressWarnings("serial")
@Entity
@Table(name = "Test")
public class TestBean implements Test, Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID_Test")
	private int id;

	// se flag � true allora il test � finale altrimenti intermedio
	@Column(name = "TipoTest")
	private boolean flag;

	@Column(name = "Descrizione")
	private String descrizione;

	@Column(name = "Data")
	private Calendar data;

	// se il test � stato corretto il flag corretto � a true
	@Column(name = "StatoTest")
	private boolean corretto;

	@ManyToOne
	@JoinColumn(name = "Corso", referencedColumnName = "ID_Corso")
	private CorsoBean corso;

	@ManyToOne
	@JoinColumn(name = "Correttore", referencedColumnName = "ID_Correttore")
	private CorrettoreBean correttore;

	@OneToOne
	@JoinColumn(name = "Contenuto", referencedColumnName = "ID_Contenuto")
	private ContenutoBean contenuto;

	@ManyToMany(cascade = CascadeType.ALL, mappedBy = "test")
	private Set<StudenteBean> studenti;

	@ManyToMany
	@JoinTable(name = "Dipendenze_Test", joinColumns = @JoinColumn(name = "ID_TestDipendente"), inverseJoinColumns = @JoinColumn(name = "ID_Test"))
	private Set<TestBean> dipendenze;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "test")
	private Set<RisultatoBean> risultati;

	@Override
	public int getID() {
		// TODO Auto-generated method stub
		return id;
	}

	@Override
	public String getDescrizione() {
		// TODO Auto-generated method stub
		return descrizione;
	}

	@Override
	public void setDescrizione(String descrizione)
			throws NotValidStringException {
		if (descrizione == null || descrizione.length() == 0)
			throw new NotValidStringException("Nessuna descrizione inserita");
		else if (descrizione.length() > 255)
			throw new NotValidStringException(
					"Stringa troppo lunga, massimo 255 caratteri");
		else
			this.descrizione = descrizione;

	}

	@Override
	public Calendar getDataTest() {
		// TODO Auto-generated method stub
		return data;
	}

	@Override
	public void setDataTest(Calendar data) throws Exception {
		if (data == null)
			throw new NotValidDataException("Data inserita non valida");

		if (corso.getAnno().toString().regionMatches(4, data.toString(), 0, 4))
			throw new NotValidDataException(
					"Anno della data inserita incoerente");

		this.data = data;
	}

	@Override
	public CorsoBean getCorso() {
		// TODO Auto-generated method stub
		return corso;
	}

	@Override
	public void setCorso(CorsoBean corso) throws NotValidCorsoException {
		// TODO Auto-generated method stub
		if (corso == null)
			throw new NotValidCorsoException("Corso non esistente!");
		else
			this.corso = corso;

	}

	@Override
	public ContenutoBean getContenuto() {
		// TODO Auto-generated method stub
		return contenuto;
	}

	@Override
	public void setContenuto(ContenutoBean contenuto)
			throws NotValidContenutoException {
		// TODO Auto-generated method stub

		if (contenuto == null)
			throw new NotValidContenutoException("Contenuto non esistente!");
		else
			this.contenuto = contenuto;
	}

	@Override
	public void aggiungiDipendenza(TestBean test)
			throws NotValidDipendenzaException {

		if (test == null)
			throw new NotValidDipendenzaException("Test non esistente");
		else if (test.getTipoTest().equals("Finale"))
			throw new NotValidDipendenzaException(
					"Non pu� dipendere da un test finale");
		else if (dipendenze.equals(this))
			throw new NotValidDipendenzaException("Dipendenza riflessiva");
		else if (dipendenze.contains(this))
			throw new NotValidDipendenzaException("Dipendenza simmetrica");
		else if (dipendenze.contains(test))
			throw new NotValidDipendenzaException("Dipendenza gi� presente");
		else
			dipendenze.add(test);
	}

	@Override
	public void eliminaDipendenza(TestBean test) throws NotValidTestException {
		// TODO Auto-generated method stub

		if (test == null)
			throw new NotValidTestException("Test non esistente!");
		else if (!dipendenze.contains(test))
			throw new NotValidTestException("Test non presente");
		else
			dipendenze.remove(test);

	}

	@Override
	public Iterator<TestBean> getIteratoreDipendenze() {
		// TODO Auto-generated method stub
		return dipendenze.iterator();
	}

	@Override
	public void aggiungiIscritto(StudenteBean studente)
			throws NotValidStudenteException, NotValidLivelloException {

		if (studente == null)
			throw new NotValidStudenteException("Studente non esistente!");
		else if (studenti.contains(studente))
			throw new NotValidStudenteException("Studente gi� presente!");
		else if (studente.getUtente().getLivelloUtente() != "studente")
			throw new NotValidLivelloException("Utente non valido");
		else
			studenti.add(studente);

	}

	@Override
	public void eliminaIscritto(StudenteBean studente)
			throws NotValidStudenteException, NotValidLivelloException {

		if (studente == null)
			throw new NotValidStudenteException("Studente non esistente!");
		else if (!studenti.contains(studente))
			throw new NotValidStudenteException("Test non presente");
		else if (studente.getUtente().getLivelloUtente() != "studente")
			throw new NotValidLivelloException("Utente non valido");
		else
			studenti.remove(studente);

	}

	@Override
	public Iterator<StudenteBean> getIteratoreIscritti() {
		return studenti.iterator();
	}

	@Override
	public void aggiungiRisultato(RisultatoBean risultato)
			throws NotValidRisultatoException {
		// TODO Auto-generated method stub

		if (risultati == null)
			throw new NotValidRisultatoException("Risultato non esistente!");
		else if (!risultato.getTest().equals(this))
			throw new NotValidRisultatoException("Risultato non valido!");
		else if (risultati.contains(risultati))
			throw new NotValidRisultatoException("Risultato gi� presente!");
		else
			risultati.add(risultato);

	}

	@Override
	public void eliminaRisultato(RisultatoBean risultato)
			throws NotValidRisultatoException {
		// TODO Auto-generated method stub
		if (risultato == null)
			throw new NotValidRisultatoException("Risultato non esistente!");
		else if (!risultati.contains(risultato))
			throw new NotValidRisultatoException("Risultato non presente!");
		else
			risultati.remove(risultato);
	}

	@Override
	public Iterator<RisultatoBean> getIteratoreRisultati() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CorrettoreBean getCorrettore() {
		// TODO Auto-generated method stub
		return correttore;
	}

	@Override
	public void setCorrettore(CorrettoreBean correttore)
			throws NotValidCorrettoreException, NotValidLivelloException {
		// TODO Auto-generated method stub

		if (correttore == null)
			throw new NotValidCorrettoreException("Correttore non esistente!");
		else if (correttore.getUtente() != null
				&& correttore.getSoftware() == null)
			if (correttore.getUtente().getLivelloUtente() != "assistente")
				throw new NotValidLivelloException("Utente non valido");
			else
				this.correttore = correttore;

	}

	@Override
	public String getTipoTest() {
		// TODO Auto-generated method stub
		if (this.flag == true)
			return "Finale";
		else
			return "Intermedio";
	}

	@Override
	public void setTipoTest(boolean tipoTest) {
		// TODO Auto-generated method stub
		this.flag = tipoTest;

	}

	@Override
	public boolean getStatoTest() {
		return corretto;
	}

	@Override
	public void setStatoTest(boolean stato) {
		this.corretto = stato;

	}

}
