package entities;

import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.persistence.*;

import entities.interfaces.Utente;
import exceptions.NotValidDataException;
import exceptions.NotValidStringException;

@SuppressWarnings("serial")
@Entity
@Table(name = "UTENTE")
public class UtenteBean implements Utente, Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private int ID;

	@Column(name = "Nome")
	private String nome;

	@Column(name = "Cognome")
	private String cognome;

	@Column(name = "CodiceFiscale")
	private String codiceFiscale;

	@Column(name = "DataNascita")
	private Calendar dataNascita;

	@Column(name = "Sesso")
	private char sesso;

	@Column(name = "Indirizzo")
	private String indirizzo;

	@Column(name = "Email")
	private String email;

	@Column(name = "LivelloUtente")
	private String livelloUtente;

	@Column(name = "Password")
	private String pwd;

	@Override
	public int getID() {
		return ID;
	}

	@Override
	public void setID(int id) {
		this.ID = id;
	}

	@Override
	public String getNome() {
		return this.nome;
	}

	@Override
	public void setNome(String nome) throws NotValidStringException {
		if (nome == null || nome.length() == 0)
			throw new NotValidStringException("Nome non inserito");
		else if (nome.length() > 255)
			throw new NotValidStringException(
					"Lunghezza non valida, massimo 255 caratteri");
		else
			this.nome = nome;
	}

	@Override
	public String getCognome() {
		return this.cognome;
	}

	@Override
	public void setCognome(String cognome) throws NotValidStringException {
		if (cognome == null || cognome.length() == 0)
			throw new NotValidStringException("Cognome non inserito");
		else if (cognome.length() > 255)
			throw new NotValidStringException(
					"Lunghezza non valida, massimo 255 caratteri");
		else
			this.cognome = cognome;
	}

	@Override
	public String getCF() {
		return this.codiceFiscale;
	}

	@Override
	public void setCF(String codiceFiscale) throws NotValidStringException {
		if (codiceFiscale == null || codiceFiscale.length() == 0)
			throw new NotValidStringException("Codice fiscale non inserito");
		else if (codiceFiscale.length() > 255)
			throw new NotValidStringException(
					"Lunghezza non valida, massimo 255 caratteri");
		else
			this.codiceFiscale = codiceFiscale;
	}

	@Override
	public Calendar getData() {
		return this.dataNascita;
	}

	@Override
	public void setData(Calendar dataNascita) throws NotValidDataException {
		Calendar annoCorrente = new GregorianCalendar();
		annoCorrente.set(2011, 1, 1);
		Calendar data = new GregorianCalendar();

		data.set(dataNascita.get(Calendar.YEAR),
				dataNascita.get(Calendar.MONTH),
				dataNascita.get(Calendar.DAY_OF_MONTH));
		data.roll(Calendar.YEAR, 18);

		if (annoCorrente.after(data))
			this.dataNascita = dataNascita;
		else
			throw new NotValidDataException("Data inserita non valida");
	}

	@Override
	public char getSesso() {
		return this.sesso;
	}

	@Override
	public void setSesso(char sesso) throws NotValidStringException {
		if (sesso != 'm' && sesso != 'f')
			throw new NotValidStringException("Valore inserito non valido");
		else
			this.sesso = sesso;
	}

	@Override
	public String getIndirizzo() {
		return this.indirizzo;
	}

	@Override
	public void setIndirizzo(String indirizzo) throws NotValidStringException {
		if (indirizzo == null || indirizzo.length() == 0)
			throw new NotValidStringException("Indirizzo non inserito");
		else if (indirizzo.length() > 255)
			throw new NotValidStringException(
					"Lunghezza non valida, massimo 255 caratteri");
		else
			this.indirizzo = indirizzo;
	}

	@Override
	public String getEmail() {
		return this.email;
	}

	@Override
	public void setEmail(String email) throws NotValidStringException {
		if (email == null || email.length() == 0)
			throw new NotValidStringException("Email non inserita");
		else if (email.length() > 255)
			throw new NotValidStringException(
					"Lunghezza non valida, massimo 255 caratteri");
		else
			this.email = email;
	}

	@Override
	public String getLivelloUtente() {
		return this.livelloUtente;
	}

	@Override
	public void setLivelloUtente(String livello) throws NotValidStringException {

		if (!livello.equals("utente") && !livello.equals("professore")
				&& !livello.equals("studente") && !livello.equals("assistente"))
			throw new NotValidStringException("Ruolo inserito non riconosciuto");

		livelloUtente = livello;
	}

	@Override
	public String getPassword() {
		return this.pwd;
	}

	@Override
	public void setPassword(String password) throws NotValidStringException {
		if (password == null || password.length() == 0)
			throw new NotValidStringException("Password non inserita");
		else if (password.length() > 255)
			throw new NotValidStringException(
					"Lunghezza non valida, massimo 255 caratteri");
		else
			this.pwd = password;
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof UtenteBean))
			return false;

		return getID() == ((UtenteBean) o).getID();
	}

}
