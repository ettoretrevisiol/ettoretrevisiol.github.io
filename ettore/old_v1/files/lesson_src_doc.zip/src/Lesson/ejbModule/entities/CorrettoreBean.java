package entities;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.*;

import entities.interfaces.*;
import exceptions.NotValidLivelloException;
import exceptions.NotValidTestException;
import exceptions.NotValidSoftwareException;

@SuppressWarnings("serial")
@Entity
@Table(name = "Correttore")
public class CorrettoreBean implements Correttore, Serializable {

	@SuppressWarnings("unused")
	@Id
	@Column(name = "ID_Correttore")
	private int ID;

	@OneToOne
	@JoinColumn(name = "Utente", referencedColumnName = "ID")
	// N.B.: pu� essere NULL
	private UtenteBean utente;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "correttore")
	private Set<TestBean> prove;

	@OneToOne
	@JoinColumn(name = "Software", referencedColumnName = "ID_Software")
	private SoftwareBean software;

	@Override
	public int getID() {
		if (this.utente != null && this.software == null)
			return utente.getID();
		else if (this.utente == null && this.software != null)
			return software.getID();
		return -1;
	}

	@Override
	public SoftwareBean getSoftware() {
		// TODO Auto-generated method stub
		return software;
	}

	@Override
	public UtenteBean getUtente() {
		return utente;
	}

	@Override
	public void setUtente(UtenteBean utente) throws NotValidLivelloException {
		if (utente.getLivelloUtente() != "assistente"
				|| utente.getLivelloUtente() != "professore")
			throw new NotValidLivelloException(
					"Livello utente inserito non valido");
		this.utente = utente;
		this.ID = utente.getID();
	}

	@Override
	public void setSoftware(SoftwareBean software)
			throws NotValidSoftwareException {
		// TODO Auto-generated method stub

		if (software == null)
			throw new NotValidSoftwareException("Software non esistente!");
		else {
			this.software = software;
			this.ID = software.getID();
		}

	}

	@Override
	public void aggiungiProva(TestBean prova) throws NotValidTestException {
		// TODO Auto-generated method stub

		if (prova == null)
			throw new NotValidTestException("Prova non esistente!");
		else if (prove.contains(prova))
			throw new NotValidTestException("Prova gi� presente!");
		else
			prove.add(prova);

	}

	@Override
	public void eliminaProva(TestBean prova) throws NotValidTestException {
		// TODO Auto-generated method stub

		if (prova == null)
			throw new NotValidTestException("Prova non esistente!");
		else if (!prove.contains(prova))
			throw new NotValidTestException("Prova non presente");
		else
			prove.remove(prova);

	}

	@Override
	public Iterator<TestBean> getIteratoreProve() {
		// TODO Auto-generated method stub
		return prove.iterator();
	}

}
