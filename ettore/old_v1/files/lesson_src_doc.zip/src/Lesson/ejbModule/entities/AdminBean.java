package entities;

import java.io.Serializable;

import javax.persistence.*;

import entities.interfaces.Amministratore;
import exceptions.NotValidStringException;

@SuppressWarnings("serial")
@Entity
@Table(name = "AMMINISTRATORE")
public class AdminBean implements Amministratore, Serializable {

	@Id
	@Column(name = "ID_Admin")
	private int ID;
	
	
	@OneToOne
	@JoinColumn(name = "ID_Utente", referencedColumnName = "ID")
	private UtenteBean persona;

	@Column(name = "TelefonoInterno")
	private String telefonoInterno;

	@Override
	public UtenteBean getPersona() {
		return this.persona;
	}

	@Override
	public void setPersona(UtenteBean p) {
		this.persona = p;
		this.ID = persona.getID();
	}

	@Override
	public int getID() {
		return ID;

	}

	@Override
	public String getNumeroInterno() {
		return this.telefonoInterno;
	}

	@Override
	public void setNumeroInterno(String telefono)
			throws NotValidStringException {
		if (telefono == null || telefono.length() == 0)
			throw new NotValidStringException("Password non inserita");
		else if (telefono.length() > 255)
			throw new NotValidStringException(
					"Lunghezza non valida, massimo 255 caratteri");
		else
			this.telefonoInterno = telefono;
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof AdminBean))
			return false;

		return this.getID() == ((AdminBean) o).getID();
	}

}
