package entities.interfaces;

import java.util.Calendar;
import java.util.Iterator;
import entities.ContenutoBean;
import entities.CorrettoreBean;
import entities.CorsoBean;
import entities.RisultatoBean;
import entities.StudenteBean;
import entities.TestBean;
import exceptions.NotValidContenutoException;
import exceptions.NotValidCorrettoreException;
import exceptions.NotValidCorsoException;
import exceptions.NotValidDipendenzaException;
import exceptions.NotValidLivelloException;
import exceptions.NotValidRisultatoException;
import exceptions.NotValidStringException;
import exceptions.NotValidStudenteException;
import exceptions.NotValidTestException;

public interface Test {

	/**
	 * ritorna l'id del test
	 * @return
	 */
	public int getID();

	/**
	 * fornisce la descrizione del test
	 * @return
	 */
	public String getDescrizione();
	
	/**
	 * dice se il test � intermedio o finale
	 * @return
	 */
	public String getTipoTest();
	
	/**
	 * imposta il tipo del test
	 * @param tipoTest
	 */
	public void setTipoTest(boolean tipoTest);

	/**
	 * @param descrizione
	 * @throws NotValidStringException
	 */
	public void setDescrizione(String descrizione) throws NotValidStringException;

	/**
	 * restituisce la data di svolgimento del test
	 * @return
	 */
	public Calendar getDataTest();

	/**
	 * @param data
	 * @throws Exception
	 */
	public void setDataTest(Calendar data) throws Exception;
	
	/**
	 * dice se il test � stato corretto o meno
	 * @return
	 */
	public boolean getStatoTest();
	
	/**
	 * setta lo stato di correzione del test
	 * @param stato
	 */
	public void setStatoTest(boolean stato);

	/**
	 * fornisce il corso a cui il test appartiene
	 * @return
	 */
	public CorsoBean getCorso();

	/**
	 * @param corso
	 * @throws NotValidCorsoException
	 */
	public void setCorso(CorsoBean corso) throws NotValidCorsoException;

	/**
	 * fornisce il contenuto del test corrispondente
	 * @return
	 */
	public ContenutoBean getContenuto();

	/**
	 * @param contenuto
	 * @throws NotValidContenutoException
	 */
	public void setContenuto(ContenutoBean contenuto) throws NotValidContenutoException;

	/**
	 * aggiunge un test alla lista dei test da cui il test in questione dipende 
	 * @param test
	 * @throws NotValidDipendenzaException
	 * 									controlla che il test non violi le regole di non riflessivit� e
	 * 									non simmetria 
	 */
	public void aggiungiDipendenza(TestBean test) throws NotValidDipendenzaException;

	/**
	 * elimina un test dalla lista dei test da cui dipende
	 * @param test
	 * @throws NotValidTestException
	 */
	public void eliminaDipendenza(TestBean test) throws NotValidTestException;

	/**
	 * fornisce l'iteratore della lista delle dipendenze
	 * @return
	 */
	public Iterator<TestBean> getIteratoreDipendenze();

	/**
	 * aggiunge uno studente al test
	 * @param studente
	 * @throws NotValidStudenteException
	 * @throws NotValidLivelloException 
	 */
	public void aggiungiIscritto(StudenteBean studente) throws NotValidStudenteException, NotValidLivelloException;

	/**
	 * elimina uno studente dal test
	 * @param studente
	 * @throws NotValidStudenteException
	 * @throws NotValidLivelloException 
	 */
	public void eliminaIscritto(StudenteBean studente) throws NotValidStudenteException, NotValidLivelloException;

	/**
	 * fornisce iteratore della lista degli studenti iscritti
	 * @return
	 */
	public Iterator<StudenteBean> getIteratoreIscritti();

	/**
	 * aggiunge un risultato alla lista dei risultati del test
	 * @param risultato
	 * @throws NotValidRisultatoException
	 */
	public void aggiungiRisultato(RisultatoBean risultato) throws NotValidRisultatoException;

	/**
	 * toglie un risultato dalla lista dei risultati
	 * @param risultato
	 * @throws NotValidRisultatoException
	 */
	public void eliminaRisultato(RisultatoBean risultato) throws NotValidRisultatoException;

	/**
	 * fornisce l'iteratore della lista degli iscritti
	 * @return
	 */
	public Iterator<RisultatoBean> getIteratoreRisultati();

	/**
	 * restituisce il correttore del test
	 * @return
	 */
	public CorrettoreBean getCorrettore();

	/**
	 * @param correttore
	 * @throws NotValidCorrettoreException
	 * @throws NotValidLivelloException 
	 */
	public void setCorrettore(CorrettoreBean correttore) throws NotValidCorrettoreException, NotValidLivelloException;

}
