package entities.interfaces;

import java.util.Iterator;
import entities.*;
import exceptions.*;

public interface Contenuto {
	/**
	 * Restituisce l'id del contenuto
	 * 
	 * @return int
	 */
	public int getID();

	/**
	 * Restituisce la descrizione del contenuto
	 * 
	 * @return String
	 */
	public String getDescrizione();

	/**
	 * Permette di impostare la descrizione del contenuto
	 * 
	 * @param descrizione
	 *            La descrizione del contenuto
	 * @throws NotValidDescriptionException
	 *             La descrizione supera i 255 caratteri
	 */
	public void setDescrizione(String descrizione)
			throws NotValidStringException;

	/**
	 * Restituisce il corso cui si riferisce il contenuto
	 * 
	 * @return CorsoBean
	 */
	public CorsoBean getCorso();

	/**
	 * Permette di impostare il corso cui si riferisce il contenuto
	 * 
	 * @param corso
	 * @throws NotValidCorsoException
	 *             Il corso non esiste
	 */
	public void setCorso(CorsoBean corso) throws NotValidCorsoException;

	/**
	 * Restituisce un iteratore per navigare tra i materiali inerenti al
	 * contenuto
	 * 
	 * @return Iterator
	 */
	public Iterator<MaterialeBean> getIteratoreMateriali();

	/**
	 * Permetti di aggiungere un materiale tra quelli inerenti al contenuto
	 * 
	 * @param materiale
	 *            Materiale da aggiungere
	 * @throws NotValidMaterialeException
	 *             Il materiale non esiste oppure non � inerente al contenuto
	 *             oppure � gi� presente nella lista
	 */
	public void aggiungiMateriale(MaterialeBean materiale)
			throws NotValidMaterialeException;

	/**
	 * Permette di rimuovere un materiale tra quelli inerenti al contenuto
	 * 
	 * @param materiale
	 *            Materiale da rimuovere
	 * @throws NotValidMaterialeException
	 *             Il materiale non esiste oppure non � presente nella lista
	 */
	public void eliminaMateriale(MaterialeBean materiale)
			throws NotValidMaterialeException;

	// public void aggiungiProva(Test test);
	// public void eliminaProva(Test prova);
	// public Iterator getIteratoreProve();

}
