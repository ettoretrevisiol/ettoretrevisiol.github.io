package entities.interfaces;

import java.util.Iterator;

import entities.CorsoBean;
import entities.UtenteBean;
import entities.RisultatoBean;
import entities.TestBean;
import exceptions.NotValidCorsoException;
import exceptions.NotValidRisultatoException;
import exceptions.NotValidTestException;

public interface Studente {

	/**
	 * fornisce l'id dello studente
	 * @return
	 */
	public int getID();

	/**
	 * restituisce tutti i dati personali dello studente
	 * 
	 * @return persona
	 */
	public UtenteBean getUtente();

	/**
	 * imposta i dati dello studente
	 * 
	 * @param p
	 */
	public void setUtente(UtenteBean utente);

	/**
	 * aggiunge un corso alla lista dei corsi frequentati o che frequentato lo
	 * studente
	 * 
	 * @param c
	 * @throws NotValidCorsoException
	 */
	public void aggiungiCorso(CorsoBean c) throws NotValidCorsoException;

	/**
	 * elimina un corso dalla lista dei corsi dello studente
	 * 
	 * @param c
	 * @throws NotValidCorsoException
	 */
	public void eliminaCorso(CorsoBean c) throws NotValidCorsoException;

	/**
	 * ritorna l'iteratore della lista dei corsi dello studente
	 * 
	 * @return
	 */
	public Iterator<CorsoBean> getIteratoreCorsi();

	/**
	 * aggiunge un test alla lista dei test da sostenere
	 * 
	 * @param t
	 * @throws NotValidTestException
	 */
	public void aggiungiTest(TestBean t) throws NotValidTestException;

	/**
	 * elimina un test dalla lista dei test dello studente
	 * 
	 * @param t
	 * @throws NotValidTestException
	 */
	public void eliminaTest(TestBean t) throws NotValidTestException;

	/**
	 * ritorna l'iteratore della lista dei test dello studente
	 * 
	 * @return
	 */
	public Iterator<TestBean> getIteratoreTest();

	/**
	 * aggiunge un voto alla lista dei voti dello studente
	 * 
	 * @param r
	 * @throws NotValidRisultatoException
	 */
	public void aggiungiRisultato(RisultatoBean r)
			throws NotValidRisultatoException;

	/**
	 * elimina un voto dalla lista dei voti dello studente
	 * 
	 * @param r
	 * @throws NotValidRisultatoException
	 */
	public void eliminaRisultato(RisultatoBean r)
			throws NotValidRisultatoException;

	/**
	 * ritorna l'iteratore della lista dei risultati ottenuti dallo studente
	 * 
	 * @return
	 */
	public Iterator<RisultatoBean> getIteratoreRisultati();

	

}
