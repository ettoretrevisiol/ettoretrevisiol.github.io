package entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import javax.persistence.*;

import entities.interfaces.Studente;
import exceptions.NotValidCorsoException;
import exceptions.NotValidRisultatoException;
import exceptions.NotValidTestException;

@SuppressWarnings("serial")
@Entity
@Table(name = "STUDENTE")
public class StudenteBean implements Studente, Serializable {

	@Id
	@Column(name = "ID_Studente")
	private int ID;
	
	@OneToOne
	@JoinColumn(name = "ID_Utente", referencedColumnName = "ID")
	private UtenteBean utente;

	@ManyToMany
	@JoinTable(name = "IscrizioneCorso", joinColumns = { @JoinColumn(name = "ID_Studente") }, inverseJoinColumns = { @JoinColumn(name = "ID_Corso") })
	private Set<CorsoBean> corsi = new HashSet<CorsoBean>();

	@ManyToMany
	@JoinTable(name = "IscrizioneTest", joinColumns = { @JoinColumn(name = "ID_Studente") }, inverseJoinColumns = { @JoinColumn(name = "ID_Test") })
	private Set<TestBean> test = new HashSet<TestBean>();

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "studente")
	private Set<RisultatoBean> risultati = new HashSet<RisultatoBean>();

	@Override
	public int getID() {
		return ID;
	}

	@Override
	public UtenteBean getUtente() {
		return utente;
	}

	@Override
	public void setUtente(UtenteBean utente) {
		this.utente = utente;
		this.ID = utente.getID();
	}

	@Override
	public void aggiungiCorso(CorsoBean c) throws NotValidCorsoException {
		if (c == null)
			throw new NotValidCorsoException("Corso inesistente");
		else if (this.corsi.contains(c))
			throw new NotValidCorsoException("Il corso esiste gi�");
		else
			this.corsi.add(c);
	}

	@Override
	public void eliminaCorso(CorsoBean c) throws NotValidCorsoException {
		if (c == null)
			throw new NotValidCorsoException("Corso inesistente");
		else if (!this.corsi.contains(c))
			throw new NotValidCorsoException("Corso non presente");
		else
			this.corsi.remove(c);
	}

	@Override
	public Iterator<CorsoBean> getIteratoreCorsi() {
		return this.corsi.iterator();
	}

	@Override
	public void aggiungiTest(TestBean t) throws NotValidTestException {
		if (t == null)
			throw new NotValidTestException("Test inesistente");
		else if (this.test.contains(t))
			throw new NotValidTestException("Il test esiste gi�");
		else
			this.test.add(t);
	}

	@Override
	public void eliminaTest(TestBean t) throws NotValidTestException {
		if (t == null)
			throw new NotValidTestException("Test inesistente");
		else if (!this.test.contains(t))
			throw new NotValidTestException("Test non presente");
		else
			this.test.remove(t);
	}

	@Override
	public Iterator<TestBean> getIteratoreTest() {
		return this.test.iterator();
	}

	@Override
	public void aggiungiRisultato(RisultatoBean r)
			throws NotValidRisultatoException {
		if (r == null)
			throw new NotValidRisultatoException("Risultato inesistente");
		else if (this.risultati.contains(r))
			throw new NotValidRisultatoException(
					"Il risultato � gi� stato acquisito");
		else
			this.risultati.add(r);
	}

	@Override
	public void eliminaRisultato(RisultatoBean r)
			throws NotValidRisultatoException {
		if (r == null)
			throw new NotValidRisultatoException("Risultato inesistente");
		else if (!this.risultati.contains(r))
			throw new NotValidRisultatoException("Riltato non presente");
		else
			this.risultati.remove(r);
	}

	@Override
	public Iterator<RisultatoBean> getIteratoreRisultati() {
		return this.risultati.iterator();
	}

}
