package entities.interfaces;

import java.util.Calendar;
import exceptions.NotValidDataException;
import exceptions.NotValidStringException;

public interface Utente {

	/**
	 * fornisce l'identificatore di una qualsiasi persona
	 * 
	 * @return ID
	 */
	public int getID();

	/**
	 * permette di settare l'id dell'utente
	 * 
	 * @param id
	 */
	public void setID(int id);

	/**
	 * ritorna il nome della persona
	 * 
	 * @return nome
	 */
	public String getNome();

	/**
	 * inserisce il nome della persona
	 * 
	 * @param nome
	 * @throws NotValidStringException
	 */
	public void setNome(String nome) throws NotValidStringException;

	/**
	 * ritorna il cognome della persona
	 * 
	 * @return cognome
	 */
	public String getCognome();

	/**
	 * inserisce il cognome della persona
	 * 
	 * @param cognome
	 * @throws NotValidStringException
	 */
	public void setCognome(String cognome) throws NotValidStringException;

	/**
	 * ritorna il codice fiscale della persona
	 * 
	 * @return codiceFiscale
	 */
	public String getCF();

	/**
	 * inserisce il codice fiscale della persona
	 * 
	 * @param codiceFiscale
	 * @throws NotValidStringException
	 */
	public void setCF(String codiceFiscale) throws NotValidStringException;

	/**
	 * ritorna la data di nascita della persona
	 * 
	 * @return dataNascita
	 */
	public Calendar getData();

	/**
	 * inserisce la data di nascita della persona e controlla che sia possibile
	 * che l'utente si possa iscrivere
	 * 
	 * @param dataNascita
	 * @throws NotValidDataException
	 */
	public void setData(Calendar dataNascita) throws NotValidDataException;

	/**
	 * ritorna il sesso della persona
	 * 
	 * @return sesso
	 */
	public char getSesso();

	/**
	 * inserisce il sesso della persona
	 * 
	 * @param sesso
	 * @throws NotValidStringException
	 */
	public void setSesso(char sesso) throws NotValidStringException;

	/**
	 * ritorna l'indirizzo della persona
	 * 
	 * @return indirizzo
	 */
	public String getIndirizzo();

	/**
	 * inserisce l'indirizzo della persona
	 * 
	 * @param indirizzo
	 * @throws NotValidStringException
	 */
	public void setIndirizzo(String indirizzo) throws NotValidStringException;

	/**
	 * restituisce l'indirizzo mail della persona
	 * 
	 * @return email
	 */
	public String getEmail();

	/**
	 * salva l'indirizzo mail della persona
	 * 
	 * @param email
	 * @throws NotValidStringException
	 */
	public void setEmail(String email) throws NotValidStringException;

	/**
	 * ritorna tutti i dati personali dell'utente
	 * 
	 * @return persona
	 */

	public String getLivelloUtente();

	/**
	 * imposta il ruolo dell'utente
	 * 
	 * @param livello
	 */
	public void setLivelloUtente(String livello) throws NotValidStringException;

	/**
	 * fornisce la password dell'utente se registrato
	 * 
	 * @return password
	 */
	public String getPassword();

	/**
	 * imposta la password dell'utente al momento della registrazione
	 * 
	 * @param password
	 * @throws NotValidStringException
	 */
	public void setPassword(String password) throws NotValidStringException;

	public boolean equals(Object o);

}
