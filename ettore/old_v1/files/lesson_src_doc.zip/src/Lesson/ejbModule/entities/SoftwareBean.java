package entities;

import java.io.Serializable;
import javax.persistence.*;

import entities.interfaces.Software;
import exceptions.NotValidStringException;

@SuppressWarnings("serial")
@Entity
@Table(name = "Software")
public class SoftwareBean implements Software, Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID_Software")
	private int id;

	@Column(name = "Nome")
	private String nome;

	@Column(name = "Descrizione")
	private String descrizione;

	@Override
	public int getID() {
		// TODO Auto-generated method stub
		return id;
	}

	@Override
	public String getDescrizione() {
		// TODO Auto-generated method stub
		return descrizione;
	}

	@Override
	public void setDescrizione(String descrizione)	throws NotValidStringException {
		if (descrizione == null || descrizione.length() == 0)
			throw new NotValidStringException("Nessuna descrizione inserita");
		else if (descrizione.length() > 255)
			throw new NotValidStringException("Stringa troppo lunga, massimo 255 caratteri");
		else
			this.descrizione = descrizione;

	}

	@Override
	public void setNome(String nome) throws NotValidStringException {
		if (nome == null || nome.length() == 0)
			throw new NotValidStringException("Nessun nome inserito");
		else if (nome.length() > 255)
			throw new NotValidStringException("Stringa troppo lunga, massimo 255 caratteri");
		this.nome = nome;
	}

	@Override
	public String getNome() {
		return nome;
	}

}
