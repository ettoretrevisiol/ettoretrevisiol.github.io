package entities;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.*;

import entities.interfaces.Assistente;
import entities.interfaces.Corso;
import exceptions.*;

@SuppressWarnings("serial")
@Entity
@Table(name = "Corso")
public class CorsoBean implements Corso, Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID_Corso")
	private int id;

	@Column(name = "Nome")
	private String nome;

	@Column(name = "Anno")
	private String anno;

	@Column(name = "Semestre")
	private String semestre;

	@Column(name = "Descrizione")
	private String descrizione;

	@ManyToMany(mappedBy = "corsi")
	private Set<StudenteBean> iscritti;

	@ManyToOne
	@JoinColumn(name = "Professore", referencedColumnName = "ID_Professore")
	private ProfessoreBean professore;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "corso")
	private Set<ContenutoBean> contenuti;

	@ManyToOne
	@JoinColumn(name = "Assistente", referencedColumnName = "ID_Assistente")
	private AssistenteBean assistente;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "corso")
	private Set<TestBean> test;

	@Override
	public int getID() {
		// TODO Auto-generated method stub
		return id;
	}

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return nome;
	}

	@Override
	public void setNome(String nome) throws NotValidStringException {
		if (nome == null || nome.length() == 0)
			throw new NotValidStringException("Nessun nome inserito");
		if (nome.length() > 255)
			throw new NotValidStringException(
					"Stringa inserita troppo lunga,massimo 255 caratteri");
		else
			this.nome = nome;

	}

	@Override
	public String getAnno() {
		// TODO Auto-generated method stub
		return anno;
	}

	@Override
	public void setAnno(String anno) throws NotValidStringException {
		if (anno == null || anno.length() == 0)
			throw new NotValidStringException("Nessun anno inserito");
		if (anno.length() > 255)
			throw new NotValidStringException(
					"Stringa inserita troppo lunga,massimo 255 caratteri");
		else
			this.anno = anno;

	}

	@Override
	public String getSemestre() {
		// TODO Auto-generated method stub
		return semestre;
	}

	@Override
	public void setSemestre(String semestre) throws NotValidStringException {
		if (semestre == null || semestre.length() == 0)
			throw new NotValidStringException("Nessun semestre inserito");
		if (semestre.length() > 255)
			throw new NotValidStringException(
					"Stringa inserita troppo lunga,massimo 255 caratteri");
		else
			this.semestre = semestre;

	}

	@Override
	public String getDescrizione() {
		// TODO Auto-generated method stub
		return descrizione;
	}

	@Override
	public void setDescrizione(String descrizione)
			throws NotValidStringException {
		if (descrizione == null || descrizione.length() == 0)
			throw new NotValidStringException("Nessuna descrizione inserita");
		if (descrizione.length() > 255)
			throw new NotValidStringException(
					"Stringa inserita troppo lunga,massimo 255 caratteri");
		else
			this.descrizione = descrizione;

	}

	@Override
	public ProfessoreBean getProfessore() {
		// TODO Auto-generated method stub
		return professore;
	}

	@Override
	public void setProfessore(ProfessoreBean professore)
			throws NotValidProfessoreException, NotValidLivelloException {
		// TODO Auto-generated method stub
		if (professore == null)
			throw new NotValidProfessoreException("Professore non esistente!");
		else if (professore.getUtente().getLivelloUtente() != "professore")
			throw new NotValidLivelloException("Utente non valido");
		else if (professore.getUtente().getLivelloUtente() != "professore")
			throw new NotValidLivelloException("Utente non valido");
		else
			this.professore = professore;

	}

	@Override
	public void aggiungiContenuto(ContenutoBean contenuto)
			throws NotValidContenutoException {
		// TODO Auto-generated method stub
		if (contenuto == null)
			throw new NotValidContenutoException("Contenuto non esistente!");
		else if (!contenuto.getCorso().equals(this))
			throw new NotValidContenutoException("Contenuto non valido!");
		else if (contenuti.contains(contenuto))
			throw new NotValidContenutoException("Contenuto già presente!");
		else
			contenuti.add(contenuto);

	}

	@Override
	public void eliminaContenuto(ContenutoBean contenuto)
			throws NotValidContenutoException {
		// TODO Auto-generated method stub
		if (contenuto == null)
			throw new NotValidContenutoException("Contenuto non esistente!");
		else if (!contenuti.contains(contenuto))
			throw new NotValidContenutoException("Contenuto non presente");
		else
			contenuti.remove(contenuto);

	}

	@Override
	public Iterator<ContenutoBean> getIteratoreContenuti() {
		// TODO Auto-generated method stub
		return contenuti.iterator();
	}

	@Override
	public String toString() {
		return descrizione;
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof CorsoBean))
			return false;

		return this.getID() == ((CorsoBean) o).getID();
	}

	@Override
	public Assistente getAssistente() {
		// TODO Auto-generated method stub
		return assistente;
	}

	@Override
	public void setAssistente(AssistenteBean assistente)
			throws NotValidLivelloException, NotValidUtenteException {
		if (assistente == null)
			throw new NotValidUtenteException("Assistente non esistente!");
		else if (assistente.getUtente().getLivelloUtente() != "assistente")
			throw new NotValidLivelloException("Utente non valido");
		else if (assistente.getUtente().getLivelloUtente() != "assistente")
			throw new NotValidLivelloException("Utente non valido");
		else
			this.assistente = assistente;

	}

	@Override
	public void aggiungiIscritto(StudenteBean iscritto)
			throws NotValidLivelloException, NotValidStudenteException {
		if (iscritto == null)
			throw new NotValidStudenteException("Studente inserito non valido");
		else if (iscritti.contains(iscritto))
			throw new NotValidStudenteException("Studente già iscritto");
		else if (iscritto.getUtente().getLivelloUtente() != "studente")
			throw new NotValidLivelloException("Utente non valido");
		else
			this.iscritti.add(iscritto);
	}

	@Override
	public void eliminaIscritto(StudenteBean iscritto)
			throws NotValidLivelloException, NotValidStudenteException {
		if (iscritto == null)
			throw new NotValidStudenteException("Studente inserito non valido");
		else if (!iscritti.contains(iscritto))
			throw new NotValidStudenteException("Studente non iscritto");
		else if (iscritto.getUtente().getLivelloUtente() != "studente")
			throw new NotValidLivelloException("Utente non valido");
		else
			iscritti.remove(iscritto);

	}

	@Override
	public Iterator<StudenteBean> getIteratoreIscritti() {
		return iscritti.iterator();
	}

	@Override
	public void aggiungiTest(TestBean test) throws NotValidTestException {
		// TODO Auto-generated method stub
		if (test == null)
			throw new NotValidTestException("Test non valido");
		else if (this.test.contains(test))
			throw new NotValidTestException("Test esiste gi�");
		else
			this.test.add(test);
		
	}

	@Override
	public void eliminaTest(TestBean test) throws NotValidTestException {
		// TODO Auto-generated method stub
		if (test == null)
			throw new NotValidTestException("Test non valido");
		else if (!this.test.contains(test))
			throw new NotValidTestException("Test non presente");
		else
			this.test.remove(test);
	}

	@Override
	public Iterator<TestBean> getIteratoreTest() {
		// TODO Auto-generated method stub
		return this.test.iterator();
	}

}
