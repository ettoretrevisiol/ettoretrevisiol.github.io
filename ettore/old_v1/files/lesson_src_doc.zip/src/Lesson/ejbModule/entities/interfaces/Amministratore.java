package entities.interfaces;

import entities.UtenteBean;
import exceptions.NotValidStringException;

public interface Amministratore {

	
	/**
	 * ritorna tutti i dati personali dell'amministratore
	 * 
	 * @return persona
	 */
	public UtenteBean getPersona();

	/**
	 * imposta i parametri personali dell'amministratore
	 * 
	 * @param p
	 */
	public void setPersona(UtenteBean p);

	/**
	 * Restituisce l'id dell'amministratore
	 * 
	 * @return int
	 */
	public int getID();

	/**
	 * ritorna il numero di telefono dell'amministratore
	 * 
	 * @return numeroInterno
	 */
	public String getNumeroInterno();

	/**
	 * inserisce il numero di telefono dell'amministratore
	 * 
	 * @param telefonoInterno
	 */
	public void setNumeroInterno(String telefonoInterno)
			throws NotValidStringException;

}
