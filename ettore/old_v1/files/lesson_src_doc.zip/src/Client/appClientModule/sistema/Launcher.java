package sistema;

import grafica.Interfaccia;
import grafica.Textual;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Launcher {

	private static int n;

	/**
	 * Contiene il metodo di avvio dell'applicazione, esegue il test di avvio e
	 * permette di scegliere il tipo di Interfaccia
	 * 
	 * @param args
	 */

	public static void main(String[] args) {

		System.out.println("Esecuzione Lesson...");

		menuInterfaccia();

		Interfaccia t = null;

		if (n == 0) {
			t = new Textual();
			t.start();
		} else {
			System.out
					.println("Visualizzazione grafica ancora non implementata");
			System.exit(0);
		}

	}

	/**
	 * Men� per la visualizzione e scelta del tipo di Interfaccia
	 */

	private static void menuInterfaccia() {

		Scanner in = new Scanner(System.in);

		System.out
				.println("Che tipo di interfaccia vuoi? <0> testuale <!0> grafica");

		try {

			n = in.nextInt();

		} catch (InputMismatchException e) {

			System.out.println("Prego inserire un valore numerico");
			menuInterfaccia();

		}

	}

}
