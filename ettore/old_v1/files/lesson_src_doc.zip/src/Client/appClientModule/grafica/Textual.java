package grafica;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import entities.AssistenteBean;
import entities.ContenutoBean;
import entities.CorsoBean;
import entities.MaterialeBean;
import entities.RisultatoBean;
import entities.StudenteBean;
import entities.TestBean;
import entities.UtenteBean;
import exceptions.NotValidLivelloException;
import exceptions.NotValidStringException;
import sessions.interfaces.*;

public class Textual implements Interfaccia {

	private int utente;
	private String passwd;
	private GuestManagerRemote gmr;
	private Context jndiContext;
	private Scanner in;

	@Override
	public void start() {

		try {
			in = new Scanner(System.in);
			init();
			menuLogin();
		} catch (Exception e) {
			System.out.println("Errore nell'inserimento dei dati");
			e.printStackTrace();
		}

	}

	// ------------------------------------------------------------------------------------------------------

	private void menuLogin() throws Exception {

		System.out.println("...::: * LOGIN * :::...\n\n");
		System.out.println("Inserisci -2 per registrarsi");

		System.out.println("Identificativo Utente:");
		utente = in.nextInt();

		if (utente != -2) {
			// tentiamo login
			System.out.println("Password:");
			passwd = in.next();

			int l = gmr.login(utente, passwd);

			if (l == -1) {
				// non esiste l'utente
				registrazione();
			} else {
				System.out.println("Sei loggato");

				if (l == 0)
					menuAmministratore();
				else if (l == 1)
					menuAssistente();
				else if (l == 2)
					menuProfessore();
				else if (l == 3)
					menuStudente();
				else
					menuErrore();
			}
		} else {
			registrazione();
		}

	}

	// ----------------------------------------------------------------------------------------------------

	private void menuErrore() {
		// TODO Auto-generated method stub
		System.exit(0);
	}

	// ---------------------------------------------------------------------------------------------------

	private void menuAssistente() {
		// TODO Auto-generated method stub

		int comando = -1;

		Object ref = null;
		try {
			ref = jndiContext
					.lookup("AssistenteManagerBean/remote-sessions.interfaces.AssistenteManagerRemote");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		AssistenteManagerRemote amr = (AssistenteManagerRemote) ref;

		while (comando != 0) {

			System.out.println("Seleziona opzione:");
			System.out.println("1. Ricerca un test");
			System.out.println("2. Ricerca un test per correzione");
			System.out.println("3. Lista studenti");
			System.out.println("4. Correggi un test");
			System.out.println("0. Uscire dal sistema");

			try {
				comando = in.nextInt();
				if (comando < 0 || comando > 3)
					System.out.println("Inserire un valore valido");
			} catch (InputMismatchException e) {
				System.out.println("Inserire un valore numerico");
			}

			if (comando == 1) {
				System.out
						.println("Inserire descrizione o una parte per il test:");
				List<TestBean> test = amr.ricercaTest(in.next());
				for (TestBean t : test) {
					System.out.print("Tipo Test: " + t.getTipoTest());
					System.out.print(" Corso: " + t.getCorso().getNome());
					System.out.print(" Data: " + t.getDataTest().toString());
					System.out.print(" Stato: " + t.getStatoTest());
					System.out.println("\n");
				}

			}

			if (comando == 2) {
				System.out.println("Lista dei test per la correzione:");
				List<TestBean> test = amr.ricercaTestCorrezione();
				for (TestBean t : test) {
					System.out.print("Tipo Test: " + t.getTipoTest());
					System.out.print(" Corso: " + t.getCorso().getNome());
					System.out.print(" Data: " + t.getDataTest().toString());
					System.out.print(" Stato: " + t.getStatoTest());
					System.out.println("\n");
				}

			}

			if (comando == 3) {
				System.out
						.println("Inserire nome, cognome o una parte per lo studente:");
				List<StudenteBean> studenti = amr.ricercaStudente(in.next());
				for (StudenteBean s : studenti) {
					System.out.print("ID: " + s.getID());
					System.out.print(" Nome: " + s.getUtente().getNome());
					System.out.print(" Cognome: " + s.getUtente().getCognome());
					System.out.println("\n");
				}

			}

			if (comando == 4) {
				// correzione test

				System.out.println("Inserire ID del test da correggere:");

				int id_test = 0;

				try {
					id_test = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				System.out.println("Inserire ID dello studente:");

				int id_studente = 0;

				try {
					id_studente = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				System.out.println("Inserire il punteggio:");

				int voto = 0;

				try {
					voto = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				System.out.println("Descrizione:");
				in.nextLine();
				String descrizione = in.next();

				try {
					amr.correggiTest(id_test, id_studente, voto, descrizione);
					System.out.println("Iscrizione completata");
				} catch (Exception e) {
					System.out.println("Iscrizione non valida");
				}

			}

			if (comando == 0) {
				System.exit(0);
			}
		}
	}

	// ---------------------------------------------------------------------------------------------------

	private void menuStudente() {

		int comando = -1;

		Object ref = null;
		try {
			ref = jndiContext
					.lookup("StudenteManagerBean/remote-sessions.interfaces.StudenteManagerRemote");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		StudenteManagerRemote smr = (StudenteManagerRemote) ref;

		while (comando != 0) {

			System.out.println("Seleziona opzione:");
			System.out.println("1. Ricerca un test");
			System.out.println("2. Ricerca un test per iscrizione");
			System.out.println("3. Iscrizione ad un test");
			System.out.println("4. Ricerca di un corso");
			System.out.println("5. Iscrizione ad un corso");
			System.out.println("6. Ricerca di un materiale");
			System.out.println("7. Ricerca dei risultati personali");
			System.out.println("0. Uscire dal sistema");

			try {
				comando = in.nextInt();
				if (comando < 0 || comando > 7)
					System.out.println("Inserire un valore valido");
			} catch (InputMismatchException e) {
				System.out.println("Inserire un valore numerico");
			}

			if (comando == 1) {
				System.out
						.println("Inserire descrizione o una parte per il test:");
				List<TestBean> test = smr.ricercaTest(in.next());
				for (TestBean t : test) {
					System.out.print("Tipo Test: " + t.getTipoTest());
					System.out.print(" Corso: " + t.getCorso().getNome());
					System.out.print(" Data: " + t.getDataTest().toString());
					System.out.print(" Stato: " + t.getStatoTest());
					System.out.println("\n");
				}
			}

			if (comando == 2) {
				System.out.println("Lista dei test cui ti puoi iscrivere:");
				List<TestBean> test = smr.ricercaTestIscrizione();
				for (TestBean t : test) {
					System.out.print("Tipo Test: " + t.getTipoTest());
					System.out.print(" Corso: " + t.getCorso().getNome());
					System.out.print(" Data: " + t.getDataTest().toString());
					System.out.print(" Stato: " + t.getStatoTest());
					System.out.println("\n");
				}
			}

			if (comando == 3) {

				System.out.println("Inserire ID del test cui iscriversi:");

				int id_test = 0;

				try {
					id_test = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				try {
					smr.iscrizioneTest(id_test);
					System.out.println("Iscrizione completata");
				} catch (Exception e) {
					System.out.println("Iscrizione non valida");
				}

			}

			if (comando == 4) {
				System.out
						.println("Inserire descrizione o una parte per il corso:");
				List<CorsoBean> corsi = smr.ricercaCorso(in.next());
				for (CorsoBean c : corsi) {
					System.out.print("ID: " + c.getID());
					System.out.print(" Nome: " + c.getNome());
					System.out.print(" Anno: " + c.getAnno());
					System.out.print(" Semestre: " + c.getSemestre());
					System.out.println("\n");
				}
			}

			if (comando == 5) {

				System.out.println("Inserire ID del corso cui iscriversi:");

				int id_corso = 0;

				try {
					id_corso = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				try {
					smr.iscrizioneCorso(id_corso);
					System.out.println("Iscrizione completata");
				} catch (Exception e) {
					System.out.println("Iscrizione non valida");
				}

			}

			if (comando == 6) {
				System.out
						.println("Inserire nome o una parte per il materiale:");
				List<MaterialeBean> materiali = smr.ricercaMateriale(in.next());
				for (MaterialeBean m : materiali) {
					System.out.print("ID: " + m.getID());
					System.out.print(" Nome: " + m.getNome());
					System.out.print(" URL: " + m.getURL());
					System.out.print(" Contenuto: "
							+ m.getContenuto().getDescrizione());
					System.out.println("\n");
				}
			}

			if (comando == 7) {
				System.out.println("Lista dei risultati:");
				List<RisultatoBean> risultati = smr.ricercaRisultato();
				for (RisultatoBean r : risultati) {
					System.out.print("Descrizione:" + r.getDescrizione());
					System.out.print(" Punteggio: " + r.getPunteggio());
					System.out.print(" Passato: " + r.getPassato());
					System.out.println("\n");
				}
			}

			if (comando == 0) {
				System.exit(0);
			}
		}
	}

	// ------------------------------------------------------------------------------------------------------

	private void menuProfessore() {

		int comando = -1;

		Object ref = null;
		try {
			ref = jndiContext
					.lookup("ProfessoreManagerBean/remote-sessions.interfaces.ProfessoreManagerRemote");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ProfessoreManagerRemote pmr = (ProfessoreManagerRemote) ref;

		while (comando != 0) {

			System.out.println("Seleziona opzione:");
			System.out.println("1. Ricerca un corso");
			System.out.println("2. Lista corsi personali");
			System.out.println("3. Crea un corso");
			System.out.println("4. Ricerca un test");
			System.out.println("5. Crea un test");
			System.out.println("6. Elenca materiale personale");
			System.out.println("7. Crea un materiale");
			System.out.println("8. Lista completa degli assistenti");
			System.out.println("9. Ricerca un contenuto");
			System.out.println("10. Lista studenti");
			System.out.println("11. Correggi un test");
			System.out.println("0. Uscire dal sistema");

			try {
				comando = in.nextInt();
				if (comando < 0 || comando > 11)
					System.out.println("Inserire un valore valido");
			} catch (InputMismatchException e) {
				System.out.println("Inserire un valore numerico");
			}

			if (comando == 1) {

				System.out.println("Inserire nome o una parte del corso:");
				List<CorsoBean> corsi = pmr.ricercaCorso(in.next());
				for (CorsoBean c : corsi) {
					System.out.print("ID: " + c.getID());
					System.out.print(" Nome: " + c.getNome());
					System.out.print(" Anno: " + c.getAnno());
					System.out.print(" Semestre: " + c.getSemestre());
					System.out.println("\n");
				}
			}

			if (comando == 2) {

				System.out.println("\n");
				System.out.println("Lista dei corsi personali:\n");
				List<CorsoBean> corsi = pmr.ricercaCorsoProfessore();
				for (CorsoBean c : corsi) {
					System.out.print("ID: " + c.getID());
					System.out.print(" Nome: " + c.getNome());
					System.out.print(" Anno: " + c.getAnno());
					System.out.print(" Semestre: " + c.getSemestre());
					System.out.println("\n");

				}
			}

			if (comando == 3) {

				// crea corso
				System.out.println("Inserire i dati per il corso");
				System.out.println("Nome:");
				String nome = in.next();
				System.out.println("Anno:");
				String anno = in.next();
				System.out.println("Semestre:");
				String semestre = in.next();
				System.out.println("Descrizione:");
				in.nextLine();
				String descrizione = in.next();

				System.out
						.println("ID dell'assistente (0 per non settarlo al momento):");

				int id_ass = 0;

				try {
					id_ass = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				try {
					pmr.creaCorso(nome, anno, semestre, descrizione, id_ass);
					System.out.println("Corso creato");
				} catch (Exception e) {
					System.out.println(e.toString());
				}

			}

			if (comando == 4) {

				System.out
						.println("Inserire descrizione o una parte per il test:");
				List<TestBean> test = pmr.ricercaTest(in.next());
				for (TestBean t : test) {
					System.out.print("Tipo Test: " + t.getTipoTest());
					System.out.print(" Corso: " + t.getCorso().getNome());
					System.out.print(" Data: " + t.getDataTest().toString());
					System.out.print(" Stato: " + t.getStatoTest());
					System.out.println("\n");

				}
			}

			if (comando == 5) {

				// crea test
				System.out.println("Inserire i dati per il test");
				System.out.println("TipoTest (0 finale, 1 intermedio):");
				int tipo = in.nextInt();

				boolean t;
				if (tipo == 0)
					t = true;
				else
					t = false;

				System.out.println("Data:");
				String data = in.next();
				System.out.println("Descrizione:");
				in.nextLine();
				String descrizione = in.next();

				System.out.println("ID del corso:");

				int id_corso = 0;

				try {
					id_corso = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				System.out
						.println("ID del test da cui dipende (0 se nessuno):");

				int id_test = 0;

				try {
					id_test = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				try {
					pmr.creaTest(t, data, descrizione, id_corso, id_test);
					System.out.println("Corso creato");
				} catch (Exception e) {
					System.out.println(e.toString());
				}

			}

			if (comando == 6) {

				System.out.println("\n");
				System.out.println("Lista dei materiali personali:\n");
				List<MaterialeBean> materiali = pmr.ricercaMateriale();
				for (MaterialeBean m : materiali) {
					System.out.print("ID: " + m.getID());
					System.out.print(" Nome: " + m.getNome());
					System.out.print(" URL: " + m.getURL());
					System.out.print(" Contenuto: "
							+ m.getContenuto().getDescrizione());
					System.out.println("\n");

				}

			}

			if (comando == 7) {

				// crea materiale
				System.out.println("Inserire i dati per il materiale");
				System.out.println("Nome:");
				String nome = in.next();
				System.out.println("Descrizione:");
				in.nextLine();
				String descrizione = in.next();
				System.out.println("URL:");
				String url = in.next();
				System.out.println("ID del contenuto:");

				int id_con = 0;

				try {
					id_con = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				try {
					pmr.creaMateriale(nome, descrizione, url, id_con);
					System.out.println("Corso creato");
				} catch (Exception e) {
					System.out.println(e.toString());
				}

			}

			if (comando == 8) {

				System.out.println("\n");
				System.out.println("Lista degli assistenti:\n");
				List<AssistenteBean> assistenti = pmr.getAssistenti();
				for (AssistenteBean a : assistenti) {
					System.out.print("ID: " + a.getID());
					System.out.print(" Nome: " + a.getUtente().getNome());
					System.out.print(" Cognome: " + a.getUtente().getCognome());
					System.out.println("\n");

				}
			}

			if (comando == 9) {

				System.out.println("Inserire nome o una parte del contenuto:");
				List<ContenutoBean> contenuti = pmr.ricercaContenuti(in.next());
				for (ContenutoBean c : contenuti) {
					System.out.print("ID: " + c.getID());
					System.out.print(" Descrizione: " + c.getDescrizione());
					System.out.print(" Corso: " + c.getCorso().getNome());
					System.out.println("\n");

				}
			}

			if (comando == 10) {
				System.out
						.println("Inserire nome, cognome o una parte per lo studente:");
				List<StudenteBean> studenti = pmr.ricercaStudente(in.next());
				for (StudenteBean s : studenti) {
					System.out.print("ID: " + s.getID());
					System.out.print(" Nome: " + s.getUtente().getNome());
					System.out.print(" Cognome: " + s.getUtente().getCognome());
					System.out.println("\n");
				}

			}

			if (comando == 11) {
				// correzione test

				System.out.println("Inserire ID del test da correggere:");

				int id_test = 0;

				try {
					id_test = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				System.out.println("Inserire ID dello studente:");

				int id_studente = 0;

				try {
					id_studente = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				System.out.println("Inserire il punteggio:");

				int voto = 0;

				try {
					voto = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				System.out.println("Descrizione:");
				in.nextLine();
				String descrizione = in.next();

				try {
					pmr.correggiTest(id_test, id_studente, voto, descrizione);
					System.out.println("Iscrizione completata");
				} catch (Exception e) {
					System.out.println("Iscrizione non valida");
				}

			}

			if (comando == 0) {
				System.exit(0);
			}

		}

	}

	// ---------------------------------------------------------------------------------------------------

	private void menuAmministratore() throws NotValidStringException,
			NotValidLivelloException {

		int comando = -1;

		Object ref = null;
		try {
			ref = jndiContext
					.lookup("AmministratoreManagerBean/remote-sessions.interfaces.AmministratoreManagerRemote");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		AmministratoreManagerRemote amr = (AmministratoreManagerRemote) ref;

		while (comando != 0) {

			System.out.println("Seleziona opzione:");
			System.out.println("1. Lista completa degli utenti");
			System.out.println("2. Ricerca un utente");
			System.out.println("3. Modifica i diritti di un utente");
			System.out.println("4. Cancella un utente");
			System.out.println("0. Uscire dal sistema");

			try {
				comando = in.nextInt();
				if (comando < 0 || comando > 5)
					System.out.println("Inserire un valore valido");
			} catch (InputMismatchException e) {
				System.out.println("Inserire un valore numerico");
			}

			if (comando == 1) {

				System.out.println("\n");
				System.out.println("Lista degli utenti:\n");

				List<UtenteBean> utenti = amr.listaUtenti();
				for (UtenteBean u : utenti) {
					System.out.print("ID: " + u.getID());
					System.out.print(" Nome: " + u.getNome());
					System.out.print(" Cognome: " + u.getCognome());
					System.out.print(" Livello: " + u.getLivelloUtente());
					System.out.println("\n");
				}

			}

			if (comando == 2) {

				System.out
						.println("Inserire nome o cognome o una loro parte dello studente:");
				List<UtenteBean> utenti = amr.ricercaUtente(in.next());
				for (UtenteBean u : utenti) {
					System.out.print("ID: " + u.getID());
					System.out.print(" Nome: " + u.getNome());
					System.out.print(" Cognome: " + u.getCognome());
					System.out.print(" Livello: " + u.getLivelloUtente());
					System.out.println("\n");
				}

			}

			if (comando == 3) {

				System.out
						.println("Inserire l'ID dell'utente cui modificare i diritti:");

				int id = 0;

				try {
					id = in.nextInt();
				} catch (InputMismatchException e) {
					System.out.println("Inserire un valore numerico");
				}

				System.out.println("Inserire livello da impostare:");

				try {
					amr.modificaDiritti(id, in.next());
					System.out.println("Diritti modificati");
				} catch (Exception e) {
					System.out.println(e.toString());
				}

			}

			if (comando == 4) {

				System.out
						.println("Inserire l'ID dello studente da cancellare:");
				try {
					amr.cancellaUtente(Integer.valueOf(in.next()));
				} catch (Exception e) {
					System.out.println(e.toString());
				}

			}

			if (comando == 0) {
				System.exit(0);
			}

		}

	}

	// --------------------------------------------------------------------------------------------------

	private void registrazione() throws Exception {

		UtenteBean utente = new UtenteBean();

		System.out.println("Utente non registrato");
		System.out.println("Inserire i dati per la registrazione");
		System.out.println("Nome:");
		in.nextLine();
		utente.setNome(in.nextLine());
		System.out.println("Cognome:");
		utente.setCognome(in.nextLine());
		System.out.println("Codice Fiscale:");
		utente.setCF(in.next());
		System.out.println("Data di nascita (gg/mm/aaaa):");
		String d = in.next();
		Calendar cal = new GregorianCalendar();
		String g, m, a;
		g = d.substring(0, 1);
		m = d.substring(3, 4);
		a = d.substring(6, 9);
		cal.set(Integer.valueOf(g), Integer.valueOf(m), Integer.valueOf(a));
		utente.setData(cal);
		System.out.println("Sesso (m/f):");
		char c = in.next().charAt(0);
		utente.setSesso(c);
		System.out.println("Indirizzo:");
		in.nextLine();
		utente.setIndirizzo(in.nextLine());
		System.out.println("E-mail:");
		utente.setEmail(in.next());
		System.out.println("Password:");
		passwd = in.next();
		utente.setPassword(passwd);

		System.out.println("Il tuo identificativo � "
				+ gmr.salvaUtente(utente, passwd));

	}

	// ---------------------------------------------------------------------------------------------------

	private void init() {

		jndiContext = null;
		try {
			jndiContext = getInitialContext();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Object ref;
		try {
			ref = jndiContext
					.lookup("GuestManagerBean/remote-sessions.interfaces.GuestManagerRemote");
			gmr = (GuestManagerRemote) ref;
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private Context getInitialContext() throws Exception {

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY,
				"org.jnp.interfaces.NamingContextFactory");
		env.put(Context.PROVIDER_URL, "localhost:1099");

		return new InitialContext(env);
	}

}
