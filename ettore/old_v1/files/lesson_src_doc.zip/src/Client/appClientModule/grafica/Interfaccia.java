package grafica;

public interface Interfaccia {

	/**
	 * Metodo di base per l'inizializzazione dell'interfaccia
	 * 
	 */
	public abstract void start();
	
}
