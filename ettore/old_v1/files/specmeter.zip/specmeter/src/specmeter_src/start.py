#!/usr/bin/env python2
#-*- coding:utf-8 -*-

import instances

if __name__ == "__main__":
	webserver = None
	besim = None
	client = None

	ins = instances.running_instances()
	for x in ins:
		if x.name == 'webserver':
			webserver = x
			print "WebServer instance already found."
		elif x.name == 'besim':
			besim = x
			print "BeSim instance already found."
		elif x.name == 'client':
			client = x
			print "JMeter client instance already found."

	if besim is None:
		besim = instances.Instance('besim')
		besim.run()
		print "Launching BeSim..."
	if webserver is None:
		webserver = instances.Instance('webserver')
		webserver.run()
		print "Launching WebServer..."
	if client is None:
		client = instances.Instance('client')
		client.run()
		print "Launching JMeter client..."

	print "WebServer initialization...."
	webserver.initialize()

	print "BeSim initialization..."
	besim.initialize()

	instances.handshake(webserver, besim)

	print "\nInitialization phase finished."
