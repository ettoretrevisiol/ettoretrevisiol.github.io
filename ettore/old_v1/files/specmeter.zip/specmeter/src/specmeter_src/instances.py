#!/usr/bin/env python2
#-*- coding:utf-8 -*-

import time
import datetime
import string
import urllib
from readconf import Parser
from boto.ec2.connection import EC2Connection
from boto.ec2.cloudwatch import CloudWatchConnection
import boto
import paramiko
import xml
import dotest


def execute(ssh, command):
	transport = ssh.get_transport()
	channel = transport.open_session()
	channel.exec_command(command)

	keep_going = True
	while keep_going:
		if channel.recv_ready():
			print channel.recv(1024)
		elif channel.exit_status_ready():
			keep_going = False
		else:
			time.sleep(1)

	channel.close()


def get_html(url):
	html = ""
	try:
		x = urllib.urlopen(url)
		html = x.read()
		x.close()
	except IOError:
		print "ERROR: Impossible to connect to {0}!".format(url)
	return html

p = Parser('ami.cfg')
p_inf = Parser('infrastructure.cfg')

aws_access_key_id = p_inf.get_value('Credentials', 'aws_access_key_id')
aws_secret_access_key = p_inf.get_value('Credentials', 'aws_secret_access_key')


class Instance():
	def __init__(self, name, instanceid=None):
		self.name = name
		self.ami = p.get_value(name, 'ami')
		self.region = p.get_value(name, 'region')
		self.zone = p.get_value(name, 'zone')
		self.size = p.get_value(name, 'size')
		self.keypair = p.get_value(name, 'keypair')
		self.user = p.get_value(name, 'user')
		self.password = p.get_value(name, 'password')
		self.rootpassword = p.get_value(name, 'rootpassword')
		self.instanceid = instanceid
		self.ip = None
		self.publicdns = None
		self.conn = EC2Connection(aws_access_key_id, aws_secret_access_key, region=boto.ec2.get_region(self.region, aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key))
		cw_regions = boto.ec2.cloudwatch.regions()
		for r in cw_regions:
			if r.name == self.region:
				self.cloudwatch = CloudWatchConnection(aws_access_key_id, aws_secret_access_key, region=r)
				break

	def run(self):
		if self.instanceid is not(None):
			return

		res = self.conn.run_instances(self.ami, key_name=self.keypair, instance_type=self.size, monitoring_enabled=True, placement=self.zone)

		self.instanceid = str(res.instances[0].id)
		self.conn.create_tags(self.instanceid, {'Name': self.name})

	def get_ip(self):
		if self.instanceid is not(None):
			if self.ip is not(None):
				return self.ip
			res = self.__instance__()
			while res.state == 'pending':
				time.sleep(5)
				res = self.__instance__()
			if res.state == 'running':
				self.ip = str(res.ip_address)
				self.publicdns = str(res.public_dns_name)
				return self.ip
			return None

	def get_state(self):
		if self.instanceid is not(None):
			return str(self.__instance__().state)

	def terminate(self):
		if self.instanceid is not(None):
			self.conn.terminate_instances(self.instanceid)
			self.instanceid = None
			self.ip = None
			self.publicdns = None

	def reboot(self):
		if self.instanceid is not(None):
			self.conn.reboot_instances(self.instanceid)

	def __str__(self):
		res = "{0}:\n".format(self.name)
		res += "- ami = {0}\n".format(self.ami)
		if self.instanceid is not(None):
			res += "- id = {0}\n".format(self.instanceid)
		if self.ip is not(None):
			res += "- ip = {0}\n".format(self.ip)
		if self.publicdns is not(None):
			res += "- public dns = {0}\n".format(self.publicdns)
		res += "- region = {0}\n".format(self.region)
		res += "- zone = {0}\n".format(self.zone)
		res += "- keypair = {0}\n".format(self.keypair)
		res += "- size = {0}".format(self.size)
		return res

	def run_command(self, command):
		return self.run_commands([command])

	def run_commands(self, commands):
		ip = self.get_ip()
		if ip is None:
			print "ERROR: Impossible to found the ip address: did you start the machine?"
			return False

		ssh = paramiko.SSHClient()
		privkey = paramiko.RSAKey.from_private_key_file('keys/{0}.pem'.format(self.keypair))
		ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

		keepOn = True
		while keepOn:
			try:
				ssh.connect(self.publicdns, username=self.user, pkey=privkey, password=self.password)
				keepOn = False
			except paramiko.AuthenticationException:
				print "ERROR: Wrong password."
				ssh.close()
				return False
			except:
				time.sleep(5)

		for command in commands:
			# ssh_stdin, ssh_stdout, ssh_stderr = ssh.exec_command(command)
			# print ssh_stdout.read()
			execute(ssh, command)

		ssh.close()
		return True

	def get_output(self, command):
		ip = self.get_ip()
		if ip is None:
			print "ERROR: Impossible to found the ip address: did you start the machine?"
			return None

		ssh = paramiko.SSHClient()
		privkey = paramiko.RSAKey.from_private_key_file('keys/{0}.pem'.format(self.keypair))
		ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

		keepOn = True
		while keepOn:
			try:
				ssh.connect(self.publicdns, username=self.user, pkey=privkey, password=self.password)
				keepOn = False
			except paramiko.AuthenticationException:
				print "ERROR: Wrong password."
				ssh.close()
				return None
			except:
				time.sleep(5)

		ssh_stdin, ssh_stdout, ssh_stderr = ssh.exec_command(command)
		stdout = ssh_stdout.read()
		stderr = ssh_stderr.read()

		ssh.close()
		return (stdout, stderr)

	def initialize(self):
		if self.instanceid is not(None):
			if self.name == 'webserver':
				self.receive_files({'/opt/apache-tomcat-5.5.27/conf/server.xml':'server.xml'})
				doc = xml.dom.minidom.parse('server.xml')
				el1 = dotest.get_field('Connector', 'port', '80', doc)
				el2 = dotest.get_field('Connector', 'port', '443', doc)
				el1.setAttribute('acceptCount', '10000')
				el2.setAttribute('acceptCount', '10000')
				el1.setAttribute('maxThreads', '15000')
				el2.setAttribute('maxThreads', '15000')
				dotest.flush_modifications('server-mod.xml', doc)
				self.send_files({'server-mod.xml':'/opt/apache-tomcat-5.5.27/conf/server.xml'})
				return self.run_commands(p_inf.get_value(self.name, "START_SCRIPT").split('\n'))
			elif self.name == 'besim':
				return self.run_commands(p_inf.get_value(self.name, "START_SCRIPT").split('\n'))
			else:
				return True

	def send_files(self, files):
		if not(isinstance(files, dict)):
			return False

		if self.instanceid is not(None):
			ip = self.get_ip()
			if ip is None:
				print "ERROR: Impossible to found the ip address: did you start the machine?"
				return

			ssh = paramiko.SSHClient()
			privkey = paramiko.RSAKey.from_private_key_file('keys/{0}.pem'.format(self.keypair))
			ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

			keepOn = True
			while keepOn:
				try:
					ssh.connect(self.publicdns, username=self.user, pkey=privkey, password=self.password)
					keepOn = False
				except paramiko.AuthenticationException:
					print "ERROR: Wrong password."
					ssh.close()
					return False
				except:
					time.sleep(5)

			sftp = ssh.open_sftp()

			for f in files:
				sftp.put(f, files[f])

			sftp.close()
			ssh.close()
			return True

	def receive_files(self, files):
		if not(isinstance(files, dict)):
			return False

		if self.instanceid is not(None):
			ip = self.get_ip()
			if ip is None:
				print "ERROR: Impossible to found the ip address: did you start the machine?"
				return

			ssh = paramiko.SSHClient()
			privkey = paramiko.RSAKey.from_private_key_file('keys/{0}.pem'.format(self.keypair))
			ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

			keepOn = True
			while keepOn:
				try:
					ssh.connect(self.publicdns, username=self.user, pkey=privkey, password=self.password)
					keepOn = False
				except paramiko.AuthenticationException:
					print "ERROR: Wrong password."
					ssh.close()
					return False
				except:
					time.sleep(5)

			sftp = ssh.open_sftp()

			for f in files:
				sftp.get(f, files[f])

			sftp.close()
			ssh.close()
			return True

	def receive_folder(self, server_folder, local_folder, no_files=[]):
		if self.instanceid is not(None):
			ip = self.get_ip()
			if ip is None:
				print "ERROR: Impossible to found the ip address: did you start the machine?"
				return

			ssh = paramiko.SSHClient()
			privkey = paramiko.RSAKey.from_private_key_file('keys/{0}.pem'.format(self.keypair))
			ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

			keepOn = True
			while keepOn:
				try:
					ssh.connect(self.publicdns, username=self.user, pkey=privkey, password=self.password)
					keepOn = False
				except paramiko.AuthenticationException:
					print "ERROR: Wrong password."
					ssh.close()
					return False
				except:
					time.sleep(5)

			sftp = ssh.open_sftp()

			files = sftp.listdir(server_folder)

			for f in files:
				if f in no_files:
					continue
				sftp.get(server_folder + "/" + f, local_folder + "/" + f)

			sftp.close()
			ssh.close()
			return True

	def get_metrics(self,
						 metrics=['CPUUtilization', 'DiskReadBytes', 'DiskReadOps',	'DiskWriteBytes',
						 			 'DiskWriteOps', 'NetworkIn', 'NetworkOut'],
						 seconds=120, folder="logs"):
		end = datetime.datetime.strptime(self.get_output('date -R -u')[0][:-7], '%a, %d %b %Y %H:%M:%S')
		deltas = datetime.timedelta(seconds=end.second, microseconds=end.microsecond)
		end = end - deltas
		start = end - datetime.timedelta(seconds=seconds)
		result = {}
		statistics = ['Average', 'Minimum', 'Maximum']
		found_metrics = self.cloudwatch.list_metrics(namespace='AWS/EC2', dimensions={'InstanceId' : self.instanceid})
		for m in found_metrics:
			found = False
			i = 0
			while not(found) and i < len(metrics):
				if metrics[i] == m.name:
					found = True
					attempts = 1
					result[metrics[i]] = m.query(start, end, statistics)
					while result[m.name] == [] and attempts < 5:
						time.sleep(1)
						result[metrics[i]] = m.query(start - datetime.timedelta(seconds=attempts), end - datetime.timedelta(seconds=attempts), statistics)
						attempts += 1
				i += 1

		buff = ''
		for m in result.iterkeys():
			buff += m + ':\n'
			for elem in sorted(result[m], key=lambda res: res[u'Timestamp']):
				buff += "- {0}: {1}, {2}, {3} [{4}]\n".format(elem[u'Timestamp'].isoformat(), elem[u'Minimum'], elem[u'Maximum'], elem[u'Average'], elem[u'Unit'])
			buff += '\n'
		with open('{0}/cw_{1}.log'.format(folder, self.name), 'w') as f:
			f.write(buff)

		return result

	def __instance__(self):
		if self.instanceid is not(None):
			reservations = self.conn.get_all_instances(self.instanceid)
			for r in reservations:
				for i in r.instances:
					if i.id == self.instanceid:
						return i
		return None


def handshake(webserver, besim):
	ip_webserver = webserver.get_ip()
	ip_besim = besim.get_ip()
	if ip_webserver is None or ip_besim is None:
		print "ERROR: Impossible to found the ip address: did you start the machine?"
		return

	# Prima fase (webserver -> besim)
	req = ""
	conf = p_inf.config.items('init_webserver')
	for x in conf:
		req += "{0}={1}&".format(string.upper(x[0]), x[1])
	req = req[0:-1].format(ip_besim)
	retr_html = get_html("http://{0}{1}/init.jsp?{2}".format(ip_webserver, p_inf.get_value("webserver", "URI"), req))
	print retr_html

	# Seconda fase (besim -> webserver)
	req = "1&0&"
	l = 'SERVER_TIME = '
	millis = retr_html[retr_html.find(l) + len(l):retr_html.find(l) + len(l) + 13]
	conf = p_inf.config.items('init_besim')
	for x in conf:
		req += "{0}&".format(x[1])
	req = req[0:-1].format(millis)
	print get_html("http://{0}{1}?{2}".format(ip_besim, p_inf.get_value("besim", "URI"), req))

def running_instances(r='us-east-1'):
	res_array = []
	conn = EC2Connection(aws_access_key_id, aws_secret_access_key, region=boto.ec2.get_region(r, aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key))
	res = conn.get_all_instances()
	for x in res:
		for i in x.instances:
			if i.state == 'running' or i.state == 'pending':
				name = None
				ami = str(i.image_id)
				for s in p.list_sections():
					if p.get_value(s, 'ami') == ami:
						name = s
						break
				if name is not(None):
					instanceid = str(i.id)
					inst = Instance(name, instanceid)
					inst.ip = str(i.ip_address)
					inst.publicdns = str(i.public_dns_name)
					res_array.insert(len(res_array), inst)
	return res_array

if __name__ == "__main__":
	pass
