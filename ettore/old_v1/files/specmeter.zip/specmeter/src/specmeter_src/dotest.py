#!/usr/bin/env python2
#-*- coding:utf-8 -*-

import xml.dom.minidom
import instances
import time
import sys
import os
from readconf import Parser

p_test = Parser('infrastructure.cfg')
doc = xml.dom.minidom.parse(p_test.get_value("test", "basejmx"))


def get_attr(elem, name='name'):
	for val in elem.attributes.values():
		if val.name == name:
			return val.value
	return None


def get_field(tag, property_name, property_value, parent=doc):
	for elem in parent.getElementsByTagName(tag):
		res = get_attr(elem, property_name)
		if res == property_value:
			return elem
	return None


def set_value(name, value, tag_name='stringProp', parent=doc):
	elem = get_field(tag_name, 'name', name, parent)
	if elem is None:
		return False

	if len(elem.childNodes) > 0:
		elem.firstChild.data = value
	else:
		elem.appendChild(doc.createTextNode(value))
	return True


def flush_modifications(file_name='test.jmx', doc=doc):
	file_object = open(file_name, "w")
	doc.writexml(file_object)


def count_instances(files, search):
	count = 0
	for l in files:
		if l.find(search) > -1 and (l.find(search + '.') > -1 or l.find(search + '-') > -1):
			count += 1
	return count


def perform(testfile='tests.txt'):
	ins = instances.running_instances()

	webserver = None
	client = None
	besim = None

	for i in ins:
		if i.name == 'webserver':
			webserver = i
		elif i.name == 'client':
			client = i
		elif i.name == 'besim':
			besim = i

	if webserver is not(None) and client is not(None) and besim is not(None):
		set_value('HTTPSampler.domain', webserver.publicdns)
		set_value('HTTPSampler.protocol', p_test.get_value("test", "protocol"))
		set_value('Behavior.filename', '{0}/{1}'.format(p_test.get_value('test', 'test_folder'), p_test.get_value("test", "behavior")))

		millis = int(round(time.time() * 1000))
		set_value('ThreadGroup.start_time', millis)
		set_value('ThreadGroup.end_time', millis)

		files = []
		test_files = {}
		results_files = {}

		test_folder = p_test.get_value('test', 'test_folder')
		jmeter_folder = p_test.get_value('test', 'jmeter_folder')

		print "Creating configuration files..."

		i = 1
		parent = get_field('collectionProp', 'name', 'ultimatethreadgroupdata')

		for x in range(len(parent.childNodes)):
			parent.removeChild(parent.firstChild)
		parent.appendChild(doc.createTextNode('\n        '))

		start_time = 0

		with open(testfile, 'r') as f:
			for line in f:
				e = doc.createElement('collectionProp')
				e.setAttribute('name', str(0) * (10 - (len(str(i)))) + str(i))
				i += 1
				e.appendChild(doc.createTextNode('\n            '))

				s1 = doc.createElement('stringProp')
				s1.setAttribute('name', '1')
				n1 = doc.createTextNode(line.split()[0])
				s1.appendChild(n1)
				e.appendChild(s1)
				e.appendChild(doc.createTextNode('\n            '))

				s2 = doc.createElement('stringProp')
				s2.setAttribute('name', '2')
				n2 = doc.createTextNode(str(start_time))
				start_time += int(line.split()[1]) + 1
				s2.appendChild(n2)
				e.appendChild(s2)
				e.appendChild(doc.createTextNode('\n            '))

				s3 = doc.createElement('stringProp')
				s3.setAttribute('name', '3')
				n3 = doc.createTextNode('1')
				s3.appendChild(n3)
				e.appendChild(s3)
				e.appendChild(doc.createTextNode('\n            '))

				s4 = doc.createElement('stringProp')
				s4.setAttribute('name', '4')
				n4 = doc.createTextNode(line.split()[1])
				s4.appendChild(n4)
				e.appendChild(s4)
				e.appendChild(doc.createTextNode('\n            '))

				s5 = doc.createElement('stringProp')
				s5.setAttribute('name', '5')
				n5 = doc.createTextNode('1')
				s5.appendChild(n5)
				e.appendChild(s5)
				e.appendChild(doc.createTextNode('\n          '))

				parent.appendChild(doc.createTextNode('  '))
				parent.appendChild(e)
				parent.appendChild(doc.createTextNode('\n        '))

		now = time.strftime("%Y%m%d-%H%M")
		newfolder = 'logs/logs-' + now
		if not os.path.exists(newfolder):
			os.makedirs(newfolder)

		log_table = "{}/test_table.jtl".format(newfolder)
		log_tree = "{}/test_tree.jtl".format(newfolder)
		log_aggregate = "{}/test_aggregate.jtl".format(newfolder)
		log_graph = "{}/test_graph.jtl".format(newfolder)

		set_value('filename', '{0}/{1}'.format(test_folder, log_table), parent=get_field('ResultCollector', 'guiclass', 'TableVisualizer'))
		set_value('filename', '{0}/{1}'.format(test_folder, log_tree), parent=get_field('ResultCollector', 'guiclass', 'ViewResultsFullVisualizer'))
		set_value('filename', '{0}/{1}'.format(test_folder, log_aggregate), parent=get_field('ResultCollector', 'guiclass', 'StatVisualizer'))
		set_value('filename', '{0}/{1}'.format(test_folder, log_graph), parent=get_field('ResultCollector', 'guiclass', 'GraphVisualizer'))

		results_files['{0}/{1}'.format(test_folder, log_table)] = log_table
		results_files['{0}/{1}'.format(test_folder, log_tree)] = log_tree
		results_files['{0}/{1}'.format(test_folder, log_aggregate)] = log_aggregate
		results_files['{0}/{1}'.format(test_folder, log_graph)] = log_graph

		name_file = "tests/test-{}.jmx".format(now)
		test_files[name_file] = '{0}/{1}'.format(test_folder, name_file)

		files.append(name_file)

		flush_modifications(files[-1])

		if len(files) == 0:
			print "No test defined!"

		else:
			print "...configuration files created."

			behavior_file = p_test.get_value("test", "behavior")
			files.append(behavior_file)
			test_files[behavior_file] = '{0}/{1}'.format(test_folder, behavior_file)

			print "Sending files to the client..."
			client.send_files(test_files)
			print "...configuration files sent."

			print "Starting the test..."
			besim.run_commands(p_test.get_value('besim', 'STATISTICS').format(start_time / 10).split('\n'))
			webserver.run_commands(p_test.get_value('webserver', 'STATISTICS').format(start_time / 10).split('\n'))
			client.run_commands(p_test.get_value('client', 'STATISTICS').format(start_time / 10).split('\n'))
			client.run_command("mkdir {0}/{1}".format(test_folder, newfolder))
			client.run_command("{0}/bin/jmeter -n -t {1}/{2}".format(jmeter_folder, test_folder, name_file))
			client.run_command("cd {0}/lib/ext && java -jar CMDRunner.jar --tool Reporter --generate-png {1}/{2}/threadsovertime.png --input-jtl {1}/{2}/test_table.jtl --plugin-type ThreadsStateOverTime --width 800 --height 600 --granulation 100 --auto-scale yes".format(jmeter_folder, test_folder, newfolder))
			results_files['{0}/{1}/threadsovertime.png'.format(test_folder, newfolder)] = '{}/threadsovertime.png'.format(newfolder)
			print "Test ended."

			print "Saving logs files into {0} folder...".format(newfolder)
			besim.receive_folder('/tmp/sar', newfolder)
			webserver.receive_folder('/tmp/sar', newfolder)
			webserver.receive_folder('/opt/apache-tomcat-5.5.27/logs', newfolder, ['tomcat.log'])
			client.receive_folder('/tmp/sar', newfolder)
			client.receive_files(results_files)

			if start_time % 60 > 0:
				start_time = start_time + (60 - (start_time % 60))

			besim.get_metrics(p_test.get_value('besim', 'CLOUDWATCH_METRICS').split('\n'), start_time, newfolder)
			webserver.get_metrics(p_test.get_value('webserver', 'CLOUDWATCH_METRICS').split('\n'), start_time, newfolder)
			client.get_metrics(p_test.get_value('client', 'CLOUDWATCH_METRICS').split('\n'), start_time, newfolder)
			print "Done.\n"

	else:
		print "ERROR: You should first execute the start.py script."


if __name__ == "__main__":
	if len(sys.argv) > 1:
		for i in range(len(sys.argv))[1:]:
			print 'Parsing file', sys.argv[i] + '...',
			try:
				with open(sys.argv[i]) as f:
					print
					perform(sys.argv[i])
			except IOError:
				print 'file not found!'
		print '\nEnd.'
	else:
		perform('tests.txt')
		print '\nEnd.'
