#!/bin/sh

PYTHON="/usr/bin/python2"
if [ ! -e "$PYTHON" ]
then
	PYTHON="/usr/bin/python"
fi

$PYTHON start.py

$PYTHON dotest.py $@

$PYTHON stopall.py -y
