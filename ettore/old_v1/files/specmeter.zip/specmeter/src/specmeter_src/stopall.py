#!/usr/bin/env python2
#-*- coding:utf-8 -*-

import instances
import sys

if __name__ == "__main__":
	ins = instances.running_instances()

	force_yes = False
	if len(sys.argv) > 1 and sys.argv[1] == '-y':
		force_yes = True

	if len(ins) > 0:
		for x in ins:
			if not(force_yes):
				s = raw_input("Do you want to shutdown the {0}? [Y/n] ".format(x.name))
			if force_yes or s.lower() != 'n':
				print "Shutting down {0}...".format(x.name)
				x.terminate()
	else:
		print "No instance running!"
