#!/usr/bin/env python2
#-*- coding:utf-8 -*-

import xml.dom.minidom
import instances
import time
import sys
import os
import math
from multiprocessing import Process
import subprocess
from readconf import Parser
import evaluate

p_test = Parser('infrastructure.cfg')
doc = xml.dom.minidom.parse(p_test.get_value("test", "basejmx"))


def get_attr(elem, name='name'):
  for val in elem.attributes.values():
    if val.name == name:
      return val.value
  return None


def get_field(tag, property_name, property_value, parent=doc):
  for elem in parent.getElementsByTagName(tag):
    res = get_attr(elem, property_name)
    if res == property_value:
      return elem
  return None


def set_value(name, value, tag_name='stringProp', parent=doc):
  elem = get_field(tag_name, 'name', name, parent)
  if elem is None:
    return False

  if len(elem.childNodes) > 0:
    elem.firstChild.data = value
  else:
    elem.appendChild(doc.createTextNode(value))
  return True


def flush_modifications(file_name='test.jmx', doc=doc):
  file_object = open(file_name, "w")
  doc.writexml(file_object)


def count_instances(files, search):
  count = 0
  for l in files:
    if l.find(search) > -1 and (l.find(search + '.') > -1 or l.find(search + '-') > -1):
      count += 1
  return count


def __retrieve_files__(instance, newfolder, i=0, results_files_names=""):
  if instance.name == 'besim':
    instance.run_command('tar -cf /tmp/logs_bes.tar /tmp/sar/')
    instance.run_command('tar -rf /tmp/logs_bes.tar /var/log/apache2/')
    instance.run_command('gzip /tmp/logs_bes.tar')
    if not os.path.exists("{}/besim".format(newfolder)):
      os.makedirs("{}/besim".format(newfolder))
    instance.receive_files({'/tmp/logs_bes.tar.gz' : "{}/logs_bes.tar.gz".format(newfolder)})
    subprocess.call(["tar", "-zxf", "{}/logs_bes.tar.gz".format(newfolder), "-C", "{}/besim/".format(newfolder)])
    subprocess.call(["rm", "{}/logs_bes.tar.gz".format(newfolder)])
  elif instance.name == 'webserver':
    #webserver.receive_folder('/tmp/sar', newfolder)
    #webserver.receive_folder('/opt/apache-tomcat-5.5.27/logs', newfolder, ['tomcat.log'])
    instance.run_command('tar -cf /ephemeral/logs_ws.tar /tmp/sar/')
    instance.run_command('tar -rf /ephemeral/logs_ws.tar /opt/apache-tomcat-5.5.27/logs/')
    instance.run_command('tar -rf /ephemeral/logs_ws.tar /ephemeral/log4j/')
    instance.run_command('gzip /ephemeral/logs_ws.tar')
    if not os.path.exists("{}/webserver".format(newfolder)):
      os.makedirs("{}/webserver".format(newfolder))
    instance.receive_files({'/ephemeral/logs_ws.tar.gz' : "{}/logs_ws.tar.gz".format(newfolder)})
    subprocess.call(["tar", "-zxf", "{}/logs_ws.tar.gz".format(newfolder), "-C", "{}/webserver/".format(newfolder)])
    subprocess.call(["rm", "{}/logs_ws.tar.gz".format(newfolder)])
  elif instance.name.find('client') == 0:
    #client.receive_folder('/tmp/sar', newfolder)
    #client.receive_files(results_files)
    instance.run_command("tar -cf /tmp/logs_client.tar /tmp/sar/")
    instance.run_command("tar -rf /tmp/logs_client.tar {}".format(results_files_names))
    instance.run_command('gzip /tmp/logs_client.tar')
    if not os.path.exists("{}/client{}".format(newfolder, i+1)):
      os.makedirs("{}/client{}".format(newfolder, i+1))
    instance.receive_files({'/tmp/logs_client.tar.gz' : "{}/logs_client{}.tar.gz".format(newfolder, i+1)})
    subprocess.call(["tar", "-zxf", "{}/logs_client{}.tar.gz".format(newfolder, i+1), "-C", "{}/client{}/".format(newfolder, i+1)])
    subprocess.call(["rm", "{}/logs_client{}.tar.gz".format(newfolder, i+1)])

def perform(testfile='tests.txt'):
  ins = instances.running_instances()

  webserver = None
  # client = None
  clients = []
  besim = None

  for i in ins:
    if i.name == 'webserver':
      webserver = i
    elif i.name == 'besim':
      besim = i
    elif i.name.find('client') == 0:
      #client = i
      clients.append(i)

  if webserver is not(None) and len(clients) > 0 and besim is not(None):
    set_value('HTTPSampler.domain', webserver.publicdns)
    set_value('HTTPSampler.protocol', p_test.get_value("test", "protocol"))
    set_value('Behavior.filename', '{0}/{1}'.format(p_test.get_value('test', 'test_folder'), p_test.get_value("test", "behavior")))

    millis = int(round(time.time() * 1000))
    set_value('ThreadGroup.start_time', millis)
    set_value('ThreadGroup.end_time', millis)

    files = []
    test_files = {}
    results_files = {}

    test_folder = p_test.get_value('test', 'test_folder')
    jmeter_folder = p_test.get_value('test', 'jmeter_folder')

    print "Creating configuration files..."

    i = 1
    parent = get_field('collectionProp', 'name', 'ultimatethreadgroupdata')

    for x in range(len(parent.childNodes)):
      parent.removeChild(parent.firstChild)
    parent.appendChild(doc.createTextNode('\n        '))

    start_time = 0

    with open(testfile, 'r') as f:
      for line in f:
        e = doc.createElement('collectionProp')
        e.setAttribute('name', str(0) * (10 - (len(str(i)))) + str(i))
        i += 1
        e.appendChild(doc.createTextNode('\n            '))

        s1 = doc.createElement('stringProp')
        s1.setAttribute('name', '1')
        # n1 = doc.createTextNode(line.split()[0])
        n1 = doc.createTextNode(str(int(math.ceil(float(line.split()[0])/len(clients)))))
        s1.appendChild(n1)
        e.appendChild(s1)
        e.appendChild(doc.createTextNode('\n            '))

        s2 = doc.createElement('stringProp')
        s2.setAttribute('name', '2')
        n2 = doc.createTextNode(str(start_time))
        start_time += int(line.split()[1]) + 10 #1
        s2.appendChild(n2)
        e.appendChild(s2)
        e.appendChild(doc.createTextNode('\n            '))

        s3 = doc.createElement('stringProp')
        s3.setAttribute('name', '3')
        n3 = doc.createTextNode('10')
        s3.appendChild(n3)
        e.appendChild(s3)
        e.appendChild(doc.createTextNode('\n            '))

        s4 = doc.createElement('stringProp')
        s4.setAttribute('name', '4')
        n4 = doc.createTextNode(line.split()[1])
        s4.appendChild(n4)
        e.appendChild(s4)
        e.appendChild(doc.createTextNode('\n            '))

        s5 = doc.createElement('stringProp')
        s5.setAttribute('name', '5')
        n5 = doc.createTextNode('10')
        s5.appendChild(n5)
        e.appendChild(s5)
        e.appendChild(doc.createTextNode('\n          '))

        parent.appendChild(doc.createTextNode('  '))
        parent.appendChild(e)
        parent.appendChild(doc.createTextNode('\n        '))

    now = time.strftime("%Y%m%d-%H%M")
    newfolder = 'logs/logs-' + now
    if not os.path.exists(newfolder):
      os.makedirs(newfolder)

    log_table = "{}/test_table.jtl".format(newfolder)
    log_tree = "{}/test_tree.jtl".format(newfolder)
    log_aggregate = "{}/test_aggregate.jtl".format(newfolder)
    log_graph = "{}/test_graph.jtl".format(newfolder)

    set_value('filename', '{0}/{1}'.format(test_folder, log_table), parent=get_field('ResultCollector', 'guiclass', 'TableVisualizer'))
    set_value('filename', '{0}/{1}'.format(test_folder, log_tree), parent=get_field('ResultCollector', 'guiclass', 'ViewResultsFullVisualizer'))
    set_value('filename', '{0}/{1}'.format(test_folder, log_aggregate), parent=get_field('ResultCollector', 'guiclass', 'StatVisualizer'))
    set_value('filename', '{0}/{1}'.format(test_folder, log_graph), parent=get_field('ResultCollector', 'guiclass', 'GraphVisualizer'))

    results_files['{0}/{1}'.format(test_folder, log_table)] = log_table
    results_files['{0}/{1}'.format(test_folder, log_tree)] = log_tree
    results_files['{0}/{1}'.format(test_folder, log_aggregate)] = log_aggregate
    results_files['{0}/{1}'.format(test_folder, log_graph)] = log_graph

    name_file = "tests/test-{}.jmx".format(now)
    test_files[name_file] = '{0}/{1}'.format(test_folder, name_file)

    files.append(name_file)

    flush_modifications(files[-1])

    if len(files) == 0:
      print "No test defined!"

    else:
      print "...configuration files created."

      behavior_file = p_test.get_value("test", "behavior")
      files.append(behavior_file)
      test_files[behavior_file] = '{0}/{1}'.format(test_folder, behavior_file)

      print "Sending files to the clients..."
      for client in clients:
        Process(target=client.send_files, args=(test_files,)).start()
        #client.send_files(test_files)
      print "...configuration files sent."

      print "Starting the test..."
      besim.run_commands(p_test.get_value('besim', 'STATISTICS').format(start_time / 10).split('\n'))
      webserver.run_commands(p_test.get_value('webserver', 'STATISTICS').format(start_time / 10).split('\n'))
      
      procs = []
      for client in clients:
        #client.run_commands(p_test.get_value('client', 'STATISTICS').format(start_time / 10).split('\n'))
        Process(target=client.run_commands, args=(p_test.get_value('client', 'STATISTICS').format(start_time / 10).split('\n'),)).start()
        client.run_command("mkdir {0}/{1}".format(test_folder, newfolder))
        
      for client in clients:
        #p = Process(target=client.run_command, args=("{0}/bin/jmeter -n -t {1}/{2}".format(jmeter_folder, test_folder, name_file),))
        p = Process(target=client.run_commands, args=(["{0}/bin/jmeter -n -t {1}/{2}".format(jmeter_folder, test_folder, name_file), "cd {0}/lib/ext && java -jar CMDRunner.jar --tool Reporter --generate-png {1}/{2}/threadsovertime.png --input-jtl {1}/{2}/test_table.jtl --plugin-type ThreadsStateOverTime --width 800 --height 600 --granulation 100 --auto-scale yes".format(jmeter_folder, test_folder, newfolder)],))
        print "Test starting on a client..."
        p.start()
        procs.append(p)
      
      for proc in procs:
        proc.join()
        print "...test ended on a client."

      #for client in clients:
      #  #client.run_command("{0}/bin/jmeter -n -t {1}/{2}".format(jmeter_folder, test_folder, name_file))
      #  client.run_command("cd {0}/lib/ext && java -jar CMDRunner.jar --tool Reporter --generate-png {1}/{2}/threadsovertime.png --input-jtl {1}/{2}/test_table.jtl --plugin-type ThreadsStateOverTime --width 800 --height 600 --granulation 100 --auto-scale yes".format(jmeter_folder, test_folder, newfolder))

      results_files['{0}/{1}/threadsovertime.png'.format(test_folder, newfolder)] = '{}/threadsovertime.png'.format(newfolder)
      print "Test ended."
      

      print "Saving logs files into {0} folder...".format(newfolder)
      
      procs = []
      
      p = Process(target=__retrieve_files__, args=(besim, newfolder,))
      p.start()
      procs.append(p)
      p = Process(target=__retrieve_files__, args=(webserver, newfolder,))
      p.start()
      procs.append(p)
      results_files_names = ""
      for n_file in results_files.iterkeys():
        results_files_names += n_file + " "
      for i in range(len(clients)):
        p = Process(target=__retrieve_files__, args=(clients[i], newfolder, i, results_files_names,))
        p.start()
        procs.append(p)
      
#      # besim.receive_folder('/tmp/sar', newfolder)
#      besim.run_command('tar -czf /tmp/logs_bes.tar.gz /tmp/sar/')
#      if not os.path.exists("{}/besim".format(newfolder)):
#        os.makedirs("{}/besim".format(newfolder))
#      besim.receive_files({'/tmp/logs_bes.tar.gz' : "{}/logs_bes.tar.gz".format(newfolder)})
#      subprocess.call(["tar", "-zxf", "{}/logs_bes.tar.gz".format(newfolder), "-C", "{}/besim/".format(newfolder)])
#      subprocess.call(["rm", "{}/logs_bes.tar.gz".format(newfolder)])
#      
#      #webserver.receive_folder('/tmp/sar', newfolder)
#      #webserver.receive_folder('/opt/apache-tomcat-5.5.27/logs', newfolder, ['tomcat.log'])
#      webserver.run_command('tar -cf /tmp/logs_ws.tar /tmp/sar/')
#      webserver.run_command('tar -rf /tmp/logs_ws.tar /opt/apache-tomcat-5.5.27/logs/ --exclude=/opt/apache-tomcat-5.5.27/logs/tomcat.log')
#      webserver.run_command('gzip /tmp/logs_ws.tar')
#      if not os.path.exists("{}/webserver".format(newfolder)):
#        os.makedirs("{}/webserver".format(newfolder))
#      webserver.receive_files({'/tmp/logs_ws.tar.gz' : "{}/logs_ws.tar.gz".format(newfolder)})
#      subprocess.call(["tar", "-zxf", "{}/logs_ws.tar.gz".format(newfolder), "-C", "{}/webserver/".format(newfolder)])
#      subprocess.call(["rm", "{}/logs_ws.tar.gz".format(newfolder)])
#      
#      for i in range(len(clients)):
#        #client.receive_folder('/tmp/sar', newfolder)
#        #client.receive_files(results_files)
#        clients[i].run_command("tar -cf /tmp/logs_client{}.tar /tmp/sar/".format(i+1))
#        results_files_names = ""
#        for n_file in results_files.iterkeys():
#          results_files_names += n_file + " "
#        clients[i].run_command("tar -rf /tmp/logs_client.tar {}".format(results_files_names))
#        clients[i].run_command('gzip /tmp/logs_client.tar')
#        if not os.path.exists("{}/client{}".format(newfolder, i+1)):
#          os.makedirs("{}/client{}".format(newfolder, i+1))
#        clients[i].receive_files({'/tmp/logs_client.tar.gz' : "{}/logs_client{}.tar.gz".format(newfolder, i+1)})
#        subprocess.call(["tar", "-zxf", "{}/logs_client{}.tar.gz".format(newfolder, i+1), "-C", "{}/client{}/".format(newfolder, i+1)])
#        subprocess.call(["rm", "{}/logs_client{}.tar.gz".format(newfolder, i+1)])


      for proc in procs:
        proc.join()

      if start_time % 60 > 0:
        start_time = start_time + (60 - (start_time % 60))

      #p = Process(target=besim.get_metrics, args=(p_test.get_value('besim', 'CLOUDWATCH_METRICS').split('\n'), start_time, "{}/besim".format(newfolder),))
      #p.start()
      #procs.append(p)
      #p = Process(target=webserver.get_metrics, args=(p_test.get_value('webserver', 'CLOUDWATCH_METRICS').split('\n'), start_time, "{}/webserver".format(newfolder),))
      #p.start()
      #procs.append(p)
      #for i in range(len(clients)):
      #  p = Process(target=clients[i].get_metrics, args=(p_test.get_value('client', 'CLOUDWATCH_METRICS').split('\n'), start_time, "{}/client{}".format(newfolder, i+1), str(i+1),))
      #  p.start()
      #  procs.append(p)

      besim.get_metrics(p_test.get_value('besim', 'CLOUDWATCH_METRICS').split('\n'), start_time, "{}/besim".format(newfolder))
      webserver.get_metrics(p_test.get_value('webserver', 'CLOUDWATCH_METRICS').split('\n'), start_time, "{}/webserver".format(newfolder))
      for i in range(len(clients)):
        clients[i].get_metrics(p_test.get_value('client', 'CLOUDWATCH_METRICS').split('\n'), start_time, "{}/client{}".format(newfolder, i+1), append_name=str(i+1))
      print "Done.\n"
      
      #print "The average error rate is {} %.".format(evaluate.test_avg_error_rate())

  else:
    print "ERROR: You should first execute the start.py script."


if __name__ == "__main__":
  if len(sys.argv) > 1:
    for i in range(len(sys.argv))[1:]:
      print 'Parsing file', sys.argv[i] + '...',
      try:
        with open(sys.argv[i]) as f:
          print
          perform(sys.argv[i])
      except IOError:
        print 'file not found!'
    print '\nEnd.'
  else:
    perform('tests.txt')
    print '\nEnd.'
