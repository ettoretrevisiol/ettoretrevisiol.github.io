#!/usr/bin/env python2
#-*- coding:utf-8 -*-

import xml.dom.minidom
from readconf import Parser
import os
import math
import sys
from multiprocessing import Process, Queue

def count_errors(filename='test_aggregate.jtl', q=None):
  doc = xml.dom.minidom.parse(filename)
  
  root = doc.firstChild
  samps = []
  for node in root.childNodes:
    if node.nodeName.find('httpSample') == 0:
      samps += [node]

  errors = 0
  for sample in samps:
    if sample.getAttribute('s').find('false') == 0:
      errors += 1
  
  if q is not(None):
    q.put([float(int(((float(errors)/len(samps))*10000)))/100])

  return (float(int(((float(errors)/len(samps))*10000)))/100, len(samps), errors)

def test_avg_error_rate(folder='logs/logs-20121030-0047/'):
  p_test = Parser('infrastructure.cfg')
  dirs = os.listdir(folder)
  q = Queue()
  procs = []
  res = []
  for s in dirs:
    if s.find('client') == 0:
      p = Process(target=count_errors, args=("{}{}{}/{}test_aggregate.jtl".format(folder, s, p_test.get_value("test", "test_folder"), folder), q,))
      p.start()
      procs += [p]
      #res += [count_errors("{}{}{}/{}test_aggregate.jtl".format(folder, s, p_test.get_value("test", "test_folder"),folder))[0]]
  for p in procs:
    res += q.get()
    p.join()
  
  return math.fsum(res)/len(res)

if __name__ == "__main__":
  if len(sys.argv) > 1:
    for i in range(len(sys.argv))[1:]:
      print 'Parsing file', sys.argv[i] + '...',
      try:
        with open(sys.argv[i]) as f:
          print
          print "The errors in the {} file are {}.".format(sys.argv[i], count_errors(sys.argv[i])[0])
      except IOError:
        print 'file not found!'
    print '\nEnd.'
  else:
    print "The average error rate is {} %.".format(test_avg_error_rate())
    print '\nEnd.'
