#!/usr/bin/env python2
#-*- coding:utf-8 -*-

import sys
import ConfigParser


class Parser():
  def __init__(self, filename):
    self.filename = filename
    self.initialized = True
    self.config = ConfigParser.ConfigParser()
    try:
      self.config.readfp(open(filename))
    except IOError:
      print "ERROR: File {0} not found.".format(filename)
      self.initialized = False

  def get_section(self, section):
    if not(self.initialized) or not(self.config.has_section(section)):
      return False
    return dict(self.config.items(section))

  def get_value(self, section, key):
    if not(self.initialized) or not(self.config.has_section(section)) or not(self.config.has_option(section, key)):
      return False
    return self.config.get(section, key)

  def list_sections(self):
    if not(self.initialized):
      return False
    return self.config.sections()

if __name__ == "__main__":
  if len(sys.argv) > 1:
    p = Parser(sys.argv[1])
    if not(p.initialized):
      print "ERROR: File {0} not found.".format(sys.argv[1])
      sys.exit(-1)
    if len(sys.argv) >= 3:
      section = sys.argv[2]
      s = p.get_section(section)
      if not(s):
        print "ERROR: Section {0} not found.".format(section)
        sys.exit(-1)
      if len(sys.argv) == 3:
        print section + ":"
        for key in p.get_section(section):
          print "- {0} = {1}".format(key, p.get_value(section, key))
      else:
        key = sys.argv[3]
        v = p.get_value(section, key)
        if not(v):
          print "ERROR: Field {0} not found inside {1}.".format(key, section)
        print v
    else:
      for section in p.list_sections():
        print section + ":"
        for key in p.get_section(section):
          print "- {0} = {1}".format(key, p.get_value(section, key))
  else:
    print "ERROR: You need to specify a settings file."

