#!/bin/bash

PYTHON="/usr/bin/python2"
if [ ! -e "$PYTHON" ]
then
	PYTHON="/usr/bin/python"
fi

let START=$(date +"%s")

$PYTHON start.py

$PYTHON dotest.py $@

$PYTHON stopall.py -y

let secs=$(date +"%s")-START
let mins=secs/60
let secs=secs-mins*60
let hours=mins/60
let mins=mins-hours*60
let days=hours/24
let hours=hours-days*24

echo ""
echo -ne "The test took"
if [ "$days" -gt 0 ]
	then echo -ne " $days days"
fi
if [ "$hours" -gt 0 ]
	then echo -ne " $hours hours"
fi
if [ "$mins" -gt 0 ]
	then echo -ne " $mins mins"
fi
if [ "$secs" -gt 0 ]
	then echo -ne " $secs secs"
fi
echo .
