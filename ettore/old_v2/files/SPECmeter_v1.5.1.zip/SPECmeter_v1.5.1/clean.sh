rm ./tests/*
echo Tests folder cleaned. 

rm -R ./logs/*
echo Logs folder cleaned. 
