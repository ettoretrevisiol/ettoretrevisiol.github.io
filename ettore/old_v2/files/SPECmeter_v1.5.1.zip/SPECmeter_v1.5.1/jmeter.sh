sh /home/specmeter/Desktop/SPECmeter_v1.6_small/apache-jmeter-2.7/bin/jmeter.sh &
