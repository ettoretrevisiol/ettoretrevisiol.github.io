#!/usr/bin/env python2
#-*- coding:utf-8 -*-

import instances
import time
from readconf import Parser
from multiprocessing import Process
from boto.ec2.volume import Volume
from boto.ec2.ec2object import TaggedEC2Object

if __name__ == "__main__":
  p_test = Parser("infrastructure.cfg")

  webserver = None
  besim = None
  # client = None
  clients = []
  n_clients = int(p_test.get_value("client", "INSTANCES"))

  ins = instances.running_instances()
  for x in ins:
    if x.name == 'webserver':
      webserver = x
      print "WebServer instance found."
    elif x.name == 'besim':
      besim = x
      print "BeSim instance found."
    elif x.name == 'client':
      #client = x
      clients.append(x)
      print "JMeter client instance found."

  if besim is None:
    print "Launching BeSim..."
    besim = instances.Instance('besim')
    besim.run()
  if webserver is None:
    print "Launching WebServer..."
    webserver = instances.Instance('webserver')
    webserver.run()
  #if client is None:
  if len(clients) < n_clients:
    n = n_clients - len(clients)
    print "Launching {} JMeter clients...".format(n)
    while n > 6:
      clients += instances.start_instances('client', 6, len(clients))
      n -= 6
      time.sleep(2)
    if n > 0:
      clients += instances.start_instances('client', n, len(clients))

  procs = []

  print "WebServer initialization...."
  #webserver.initialize()
  p = Process(target=webserver.initialize)
  p.start()
  procs.append(p)

  print "BeSim initialization..."
  #besim.initialize()
  p = Process(target=besim.initialize)
  p.start()
  procs.append(p)
  
  for p in procs:
    p.join()

  instances.handshake(webserver, besim)

  print "\nInitialization phase finished."

